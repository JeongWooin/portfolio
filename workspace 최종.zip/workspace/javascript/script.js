function search() {
		window.location = "project_search.jsp";
	}
	function join() {
		window.location = "project_join.jsp";
	}