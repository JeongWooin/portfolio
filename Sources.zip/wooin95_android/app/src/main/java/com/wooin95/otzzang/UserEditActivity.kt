package com.wooin95.otzzang

import android.util.Log
import android.widget.Toast
import com.wooin95.otzzang.model.User
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.EditTextUtils
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_user_edit.*
import okhttp3.ResponseBody
import org.jetbrains.anko.startActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.widget.Spinner
import android.widget.ArrayAdapter
import java.util.*


class UserEditActivity : BaseActivity() {

    override fun setDefault() {
        toolbarTitle = "내 정보 수정"
        CredentialsManager.instance.activeUser.second!!.run {
            nameInput.setText(name)
            val years = ArrayList<String>()
            val thisYear = Calendar.getInstance().get(Calendar.YEAR)
            for (i in 1950..thisYear) {
                years.add(Integer.toString(i))
            }
            val adapter = ArrayAdapter<String>(this@UserEditActivity, android.R.layout.simple_dropdown_item_1line, years)
            yearSpinner.adapter = adapter
            yearSpinner.setSelection(years.indexOf(birthYear))
            when(sex){
                "선택하지 않음" -> sexSpinner.setSelection(0)
                "남자" -> sexSpinner.setSelection(1)
                "여자" -> sexSpinner.setSelection(2)
            }
            heightInput.setText(if(height == 0) "" else height.toString())
            weightInput.setText(if(weight == 0) "" else weight.toString())
        }
        confirm.setOnClickListener {
            val height = if(heightInput.text.toString().trim() == "") 0 else heightInput.text.toString().trim().toInt()
            val weight = if(weightInput.text.toString().trim() == "") 0 else weightInput.text.toString().trim().toInt()
            
            NetworkHelper.networkInstance.editUser(
                    CredentialsManager.instance.activeUser.second!!.token,
                    nameInput.text.toString().trim(),
                    yearSpinner.selectedItem.toString().toInt(),
                    sexSpinner.selectedItem.toString(),
                    height,
                    weight
            ).enqueue(object : Callback<User> {
                override fun onFailure(call: Call<User>?, t: Throwable?) {
                    Log.e("asdf", t!!.localizedMessage)
                }

                override fun onResponse(call: Call<User>?, response: Response<User>) {
                    when (response.code()) {
                        200 -> {
                            Toast.makeText(applicationContext, "정보 수정이 정상적으로 완료되었습니다.", Toast.LENGTH_SHORT).show()
                            CredentialsManager.instance.setUser(response.body()!!)
                            finish()
                        }
                        401 -> {
                            Toast.makeText(applicationContext, "관리자에게 문의해주세요.", Toast.LENGTH_SHORT).show()
                        }
                        else -> {
                            Log.e("asdf", response.message())
                        }
                    }
                }
            })
        }
    }

    override val viewId: Int = R.layout.activity_user_edit
    override val toolbarId: Int = R.id.toolbar

}
