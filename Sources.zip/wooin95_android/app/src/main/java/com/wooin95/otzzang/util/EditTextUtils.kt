package com.wooin95.otzzang.util

import android.widget.EditText

object EditTextUtils{
    fun isFullFilled(vararg editTexts : EditText) : Boolean{
        for(i in editTexts){
            if(i.text.toString().trim() == "") return false
        }
        return true
    }
}

