package com.wooin95.otzzang

import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.LinearLayoutManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.LinearLayout
import com.github.nitrico.lastadapter.LastAdapter
import com.wooin95.otzzang.databinding.ContentHashtagListBinding
import com.wooin95.otzzang.model.Cloth
import com.wooin95.otzzang.model.HashTag
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_hash_tag_control.*
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.startActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class HashTagSearchActivity : BaseActivity() {

    var dataArray = ArrayList<HashTag>()
    val dataAdapter by lazy { LastAdapter(dataArray, BR.content) }
    var call: Call<ArrayList<HashTag>>? = null
    override fun setDefault() {
        toolbarTitle = "해시태그로 게시글 검색"
        initView()
    }

    private fun initView() {
        searchRecylerView.addItemDecoration(DividerItemDecoration(applicationContext, LinearLayout.VERTICAL))
        searchRecylerView.layoutManager = LinearLayoutManager(this@HashTagSearchActivity)
        dataAdapter
                .map<HashTag, ContentHashtagListBinding>(R.layout.content_hashtag_list) {
                    onBind {
                        val item = dataArray[it.adapterPosition]
                        it.binding.title.text = "${item.tag} (${item.clothTokens.size})"
                    }
                    onClick {
                        val item = dataArray[it.adapterPosition]
                        startActivity(intentFor<ClothSearchListActivity>("query" to item.tag, "cloths" to item.clothTokens))
                        finish()
                    }
                }
                .into(searchRecylerView)
        searchQuery.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                getData(p0.toString().trim())
            }
        })
        getData("")
    }

    private fun getData(s: String) {
        call = NetworkHelper.networkInstance.findHashTagByQueryExceptZero(CredentialsManager.instance.activeUser.second!!.token, s)
        call!!.enqueue(object : Callback<ArrayList<HashTag>> {
            override fun onFailure(call: Call<ArrayList<HashTag>>?, t: Throwable?) {
                Log.e("asdf", t!!.localizedMessage)
            }

            override fun onResponse(call: Call<ArrayList<HashTag>>?, response: Response<ArrayList<HashTag>>?) {
                val state = response!!.code()
                when (state) {
                    200 -> {
                        dataArray.clear()
                        for (i in response.body()!!) {
                            if (i.clothTokens.size != 0) dataArray.add(i)
                        }
                        dataAdapter.notifyItemRangeChanged(0, dataArray.size)
                        dataAdapter.notifyDataSetChanged()
                    }
                    else -> Log.e("asdf", response.message())
                }
            }
        })
    }

    override val viewId: Int = R.layout.activity_hash_tag_search
    override val toolbarId: Int = R.id.toolbar
}
