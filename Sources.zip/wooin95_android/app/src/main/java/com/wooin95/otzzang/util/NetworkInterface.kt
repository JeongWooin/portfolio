package com.wooin95.otzzang.util

import com.wooin95.otzzang.model.Cloth
import com.wooin95.otzzang.model.HashTag
import com.wooin95.otzzang.model.User
import com.wooin95.otzzang.model.Weather
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*

public interface NetworkInterface {


    @POST("/auth/login")
    @FormUrlEncoded
    fun login(
            @Field("email") email: String,
            @Field("password") password: String
    ): Call<User>

    @POST("/auth/login/auto")
    @FormUrlEncoded
    fun autoLogin(
            @Field("token") token: String
    ): Call<User>

    @POST("/auth/register")
    @FormUrlEncoded
    fun register(
            @Field("email") email: String,
            @Field("password") password: String,
            @Field("nickname") nickname: String,
            @Field("name") name: String,
            @Field("birthYear") birthYear: Int,
            @Field("sex") sex: String,
            @Field("height") height: Int,
            @Field("weight") weight: Int
    ): Call<ResponseBody>

    @POST("/auth/user/edit")
    @FormUrlEncoded
    fun editUser(
            @Field("token") token: String,
            @Field("name") name: String,
            @Field("birthYear") birthYear: Int,
            @Field("sex") sex: String,
            @Field("height") height: Int,
            @Field("weight") weight: Int
    ): Call<User>

    @POST("/auth/user/edit/password")
    @FormUrlEncoded
    fun editUserPassword(
            @Field("token") token: String,
            @Field("password") password: String,
            @Field("newPassword") newPassword: String
    ): Call<User>

    @POST("/auth/user/remove")
    @FormUrlEncoded
    fun userWithdrawl(
            @Field("token") token: String
    ): Call<ResponseBody>

    @POST("/cloth/list")
    @FormUrlEncoded
    fun getClothList(
            @Field("token") token: String,
            @Field("weather") weather: ArrayList<Int>,
            @Field("clothType") clothType: Int
    ): Call<ArrayList<Cloth>>

    @GET("/cloth/info")
    fun getClothInfo(
            @Query("_id") _id: String
    ): Call<Cloth>

    @POST("/cloth/new")
    @FormUrlEncoded
    fun newCloth(
           @Field("token") token: String,
           @Field("title") title: String,
           @Field("weather") weather: ArrayList<Int>,
           @Field("clothType") clothType: Int,
           @Field("hashTag") hashTag: ArrayList<String>
    ) : Call<Cloth>


    @POST("/cloth/edit")
    @FormUrlEncoded
    fun editCloth(
            @Field("_id") id : String,
            @Field("clothToken") clothToken: String,
            @Field("token") userToken: String,
            @Field("title") title: String,
            @Field("weather") weather: ArrayList<Int>,
            @Field("clothType") clothType: Int,
            @Field("hashTag") hashTag: ArrayList<String>,
            @Field("originHashTag") originHashTag: ArrayList<String>
    ) : Call<Cloth>

    @Multipart
    @POST("/cloth/edit/file")
    fun editClothFile(
            @Part("clothToken") clothToken: RequestBody,
            @Part("token") userToken: RequestBody,
            @Part("file\"; filename=\"image.jpg\" ") file: RequestBody
    ) : Call<Cloth>

    @POST("/cloth/remove")
    @FormUrlEncoded
    fun removeCloth(
            @Field("_id") id : String,
            @Field("clothToken") clothToken: String,
            @Field("userToken") userToken: String
    ) : Call<ResponseBody>

    @POST("/cloth/removeAll")
    @FormUrlEncoded
    fun removeAllCloth(
            @Field("userToken") userToken: String
    ) : Call<ResponseBody>

    @POST("/cloth/hashtag/new")
    @FormUrlEncoded
    fun newHashTag(
            @Field("userToken") userToken: String,
            @Field("title") title: String
    ) : Call<ResponseBody>

    @POST("/cloth/hashtag/findExceptZero")
    @FormUrlEncoded
    fun findHashTagByQueryExceptZero(
            @Field("userToken") userToken: String,
            @Field("query") query : String
    ) : Call<ArrayList<HashTag>>

    @POST("/cloth/hashtag/find")
    @FormUrlEncoded
    fun findHashTagByQuery(
            @Field("userToken") userToken: String,
            @Field("query") query : String
    ) : Call<ArrayList<HashTag>>

    @POST("/cloth/hashtag/info")
    @FormUrlEncoded
    fun findClothByHashTag(
            @Field("query") query : String
    ) : Call<ArrayList<Cloth>>

    @GET("/weather")
    fun getWeather(
            @Query("latitude") lat : String,
            @Query("longitude") lon: String
    ) : Call<Weather>



}