package com.wooin95.otzzang.model

import com.google.gson.JsonObject
import com.google.gson.annotations.SerializedName
import org.jetbrains.annotations.Nullable

data class Weather(
        var address: String,
        var pm10: Int,
        var uvValue: Double,
        var current: ArrayList<String>,
        @SerializedName("pubdate") var pubDate: String,
        var today: ArrayList<Today>,
        var week: ArrayList<Week>,
        var currentTempMax : String,
        var currentTempMin : String,
        var todayTemps : ArrayList<String>
)

data class Today(
        var seq: Int,
        var hour: Int,
        var day: Int,
        var temp: Double,
        var tmx: Double,
        var tmn: Double,
        var wfKor: String
) {
    var hourText = "${hour}시"
}

data class Week(
        var tmEf: String,
        var wf: String,
        var tmn: Int,
        var tmx: Int
)

data class CombinedWeek(
        var tmEf: String,
        var wf1: String,
        var wf2: String,
        var tmn: Float,
        var tmx: Float
)