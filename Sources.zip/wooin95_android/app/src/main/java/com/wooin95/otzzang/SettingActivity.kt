package com.wooin95.otzzang

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.RingtoneManager
import android.os.Build
import android.provider.Settings
import android.support.v4.app.NotificationCompat
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.View
import android.widget.Toast
import com.afollestad.materialdialogs.MaterialDialog
import com.github.nitrico.lastadapter.LastAdapter
import com.wooin95.otzzang.databinding.ContentSettingsBinding
import com.wooin95.otzzang.databinding.ContentSettingsHeaderBinding
import com.wooin95.otzzang.model.Weather
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_setting.*
import kotlinx.android.synthetic.main.content_settings_header.*
import okhttp3.ResponseBody
import org.jetbrains.anko.clearTask
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.newTask
import org.jetbrains.anko.startActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*


class SettingActivity : BaseActivity() {

    val alarmMgr: AlarmManager by lazy { getSystemService(Context.ALARM_SERVICE) as AlarmManager }
    lateinit var alarmIntent: PendingIntent

    var dataArray = ArrayList<Any>()
    val dataAdapter by lazy { LastAdapter(dataArray, BR.content) }
    override fun setDefault() {
        toolbarTitle = "설정"
        alarmIntent = Intent(this@SettingActivity, AlarmReceiver::class.java).let { intent ->
            PendingIntent.getBroadcast(this@SettingActivity, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
        }
        initView()
    }

    private fun initView() {
        settingsRecyclerView.layoutManager = LinearLayoutManager(this@SettingActivity)
        Collections.addAll(dataArray,
                Header("알람"),
                "옷 정보 초기화", "내 정보 수정", "비밀번호 수정", "로그아웃", "회원탈퇴")
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            dataArray.add(1, "알림 설정")
        }
        dataAdapter
                .map<Header, ContentSettingsHeaderBinding>(R.layout.content_settings_header) {
                    onBind { it ->
                        CredentialsManager.instance.run {
                            it.binding.run {
                                switchOn.isChecked = notification
                                monday.isChecked = mondayV
                                tuesday.isChecked = tuesdayV
                                wednesday.isChecked = wednesdayV
                                thursday.isChecked = thursdayV
                                friday.isChecked = fridayV
                                saturday.isChecked = saturdayV
                                sunday.isChecked = sundayV
                                sound.isChecked = soundV
                                vibrate.isChecked = vibrateV

                                switchOn.setOnCheckedChangeListener { compoundButton, b ->
                                    notification = b
                                    initAlertSettingsView(b)
                                }

                                val arr = arrayListOf(monday, tuesday, wednesday, thursday, friday, saturday, sunday, sound, vibrate)
                                for (i in arr) i.isEnabled = notification
                                monday.setOnCheckedChangeListener { compoundButton, b -> mondayV = b }
                                tuesday.setOnCheckedChangeListener { compoundButton, b -> tuesdayV = b }
                                wednesday.setOnCheckedChangeListener { compoundButton, b -> wednesdayV = b }
                                thursday.setOnCheckedChangeListener { compoundButton, b -> thursdayV = b }
                                friday.setOnCheckedChangeListener { compoundButton, b -> fridayV = b }
                                saturday.setOnCheckedChangeListener { compoundButton, b -> saturdayV = b }
                                sunday.setOnCheckedChangeListener { compoundButton, b -> sundayV = b }
                                sound.setOnCheckedChangeListener { compoundButton, b -> soundV = b }
                                vibrate.setOnCheckedChangeListener { compoundButton, b -> vibrateV = b }

                                timeText.text = "알림시간 ${notiHour}시 ${notiMin}분"
                                val calendar = Calendar.getInstance()
                                timeChangeContainer.setOnClickListener {
                                    if (notification) {
                                        TimePickerDialog(this@SettingActivity, TimePickerDialog.OnTimeSetListener { p0, p1: Int, p2: Int ->
                                            notiHour = p1
                                            notiMin = p2
                                            timeText.text = "알림시간 ${notiHour}시 ${notiMin}분"
                                            setAlarm(p1, p2)

                                        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false)
                                                .show()
                                    }
                                }
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    vibrate.visibility = View.GONE
                                    sound.visibility = View.GONE
                                }
                            }
                        }
                    }
                }
                .map<String, ContentSettingsBinding>(R.layout.content_settings) {
                    onBind {
                        when (dataArray[it.adapterPosition]) {
                            "옷 정보 초기화" -> it.binding.image.setImageResource(R.drawable.delete)
                            "내 정보 수정" -> it.binding.image.setImageResource(R.drawable.user)
                            "비밀번호 수정" -> it.binding.image.setImageResource(R.drawable.ic_user_edit)
                            "로그아웃" -> it.binding.image.setImageResource(R.drawable.ic_logout)
                            "회원탈퇴" -> it.binding.image.setImageResource(R.drawable.ic_withdrawl)
                            "알림 설정" -> it.binding.image.setImageResource(R.drawable.ic_notifications_active_black_24dp)
                        }
                    }
                    onClick {
                        when (dataArray[it.adapterPosition]) {
                            "옷 정보 초기화" -> reset()
                            "내 정보 수정" -> editUser()
                            "비밀번호 수정" -> editPassword()
                            "로그아웃" -> logout()
                            "회원탈퇴" -> withDrawal()
                            "알림 설정" -> {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    val intent = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                                            .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                                            .putExtra(Settings.EXTRA_CHANNEL_ID, "wooin950")
                                    startActivity(intent)
                                }
                            }
                        }
                    }
                }
                .into(settingsRecyclerView)
    }

    private fun initAlertSettingsView(enabled: Boolean) {
        val arr = arrayListOf(monday, tuesday, wednesday, thursday, friday, saturday, sunday, sound, vibrate)
        for (i in arr) i.isEnabled = enabled
    }


    private fun reset() {
        MaterialDialog.Builder(this@SettingActivity)
                .content("옷 정보를 초기화하시겠습니까?")
                .positiveText("네")
                .negativeText("아니오")
                .onPositive { dialog, which ->
                    NetworkHelper.networkInstance.removeAllCloth(
                            CredentialsManager.instance.activeUser.second!!.token
                    ).enqueue(object : Callback<ResponseBody> {
                        override fun onFailure(call: Call<ResponseBody>?, t: Throwable?) {
                            Log.e("asdf", t!!.localizedMessage)
                        }

                        override fun onResponse(call: Call<ResponseBody>?, response: Response<ResponseBody>?) {
                            when (response!!.code()!!) {
                                200 -> Toast.makeText(applicationContext, "정상적으로 삭제되었습니다.", Toast.LENGTH_SHORT).show()
                                else -> Log.e("asdf", response.message())
                            }
                        }
                    })
                }
                .show()
    }

    private fun editUser() {
        startActivity<UserEditActivity>()
    }

    private fun editPassword() {
        startActivity<PasswordEditActivity>()
    }

    private fun logout() {
        MaterialDialog.Builder(this@SettingActivity)
                .content("로그아웃하시겠습니까?")
                .positiveText("네")
                .negativeText("아니오")
                .onPositive { dialog, which ->
                    CredentialsManager.instance.removeAllData()
                    startActivity(intentFor<SplashActivity>().newTask().clearTask())
                }
                .show()
    }

    private fun withDrawal() {
        MaterialDialog.Builder(this@SettingActivity)
                .content("오늘의 옷쨩에서 탈퇴하시겠습니까?")
                .positiveText("네")
                .negativeText("아니오")
                .onPositive { dialog, which ->
                    NetworkHelper.networkInstance.userWithdrawl(
                            CredentialsManager.instance.activeUser.second!!.token
                    ).enqueue(object : Callback<ResponseBody> {
                        override fun onFailure(call: Call<ResponseBody>?, t: Throwable?) {
                            Log.e("asdf", t!!.localizedMessage)
                        }

                        override fun onResponse(call: Call<ResponseBody>?, response: Response<ResponseBody>?) {
                            when (response!!.code()!!) {
                                200 -> {
                                    Toast.makeText(applicationContext, "정상적으로 탈퇴되었습니다.", Toast.LENGTH_SHORT).show()
                                    CredentialsManager.instance.removeAllData()
                                    startActivity(intentFor<SplashActivity>().newTask().clearTask())
                                }
                            }
                        }
                    })
                }
                .show()
    }

    private fun setAlarm(hour: Int, minute: Int) {
        alarmMgr.cancel(alarmIntent)
        val calendar: Calendar = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
        }
        alarmMgr.setRepeating(
                AlarmManager.RTC,
                calendar.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                alarmIntent
        )
        CredentialsManager.instance.clearAlarmTime()
    }


    fun ringAlarm(weather: Weather) {
        val p0 = applicationContext
        val intent = Intent(p0, WeatherActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(p0, 0, intent, PendingIntent.FLAG_ONE_SHOT)

        val largeIcon = BitmapFactory.decodeResource(p0!!.resources, R.mipmap.ic_launcher)
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val notificationBuilder = NotificationCompat.Builder(p0!!, "wooin95")
                .setLargeIcon(largeIcon)
                .setContentTitle(p0!!.getString(R.string.app_name))
                .setContentText(weather.current[0])
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent)
                .setSmallIcon(R.mipmap.ic_launcher)
        CredentialsManager.instance.run {
            if (!vibrateV && !soundV) {
                notificationBuilder
                        .setDefaults(Notification.DEFAULT_LIGHTS)
                        .setSound(null)
                        .setVibrate(null)
            } else if (!vibrateV) {
                notificationBuilder
                        .setDefaults(Notification.DEFAULT_SOUND)
                        .setVibrate(null)
            } else if (!soundV) {
                // !soundV
                notificationBuilder
                        .setDefaults(Notification.DEFAULT_VIBRATE)
                        .setSound(null)
            } else {
                notificationBuilder
                        .setDefaults(Notification.DEFAULT_ALL)
            }
        }
        val notificationManager = p0!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        notificationManager.notify(12034, notificationBuilder.build())
        CredentialsManager.instance.setLastAlarmTime(System.currentTimeMillis())
    }

    override val viewId: Int = R.layout.activity_setting
    override val toolbarId: Int = R.id.toolbar
}

data class Header(var title: String)
