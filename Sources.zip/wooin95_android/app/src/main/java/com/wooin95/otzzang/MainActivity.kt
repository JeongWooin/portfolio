package com.wooin95.otzzang

import android.Manifest
import android.annotation.SuppressLint
import android.location.Geocoder
import android.location.Location
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.android.gms.location.*
import com.gun0912.tedpermission.PermissionListener
import com.gun0912.tedpermission.TedPermission
import com.wooin95.otzzang.model.Today
import com.wooin95.otzzang.model.Weather
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.startActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*


class MainActivity : BaseActivity() {
    override fun setDefault() {
        initUI()
        checkPermission()
    }

    override val viewId: Int = R.layout.activity_main
    override val toolbarId: Int = 0

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var mLocationRequest: LocationRequest? = null

    private val UPDATE_INTERVAL = (10 * 1000).toLong()  /* 10 secs */
    private val FASTEST_INTERVAL: Long = 2000 /* 2 sec */

    fun checkPermission() {
        TedPermission.with(this@MainActivity)
                .setPermissions(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .setPermissionListener(object : PermissionListener {
                    override fun onPermissionGranted() {
                        startLocationUpdates()

                    }

                    override fun onPermissionDenied(deniedPermissions: MutableList<String>?) {
                        Toast.makeText(applicationContext, "위치, 저장 권한이 있어야 어플리케이션 실행이 가능합니다.", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                })
                .check()
    }

    // Trigger new location updates at interval
    @SuppressLint("MissingPermission")
    protected fun startLocationUpdates() {

        // Create the location request to start receiving updates
        mLocationRequest = LocationRequest()
        mLocationRequest!!.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
        mLocationRequest!!.setInterval(UPDATE_INTERVAL)
        mLocationRequest!!.setFastestInterval(FASTEST_INTERVAL)

        val builder = LocationSettingsRequest.Builder()
        builder.addLocationRequest(mLocationRequest!!)
        val locationSettingsRequest = builder.build()

        val settingsClient = LocationServices.getSettingsClient(this)
        settingsClient.checkLocationSettings(locationSettingsRequest)

        fusedLocationClient.requestLocationUpdates(mLocationRequest, object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult?) {
                initData(locationResult!!.lastLocation)
            }
        }, Looper.myLooper())
    }

    fun initUI() {
        val gCoder = Geocoder(applicationContext, Locale.getDefault())
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        showClothList.setOnClickListener {
            startActivity<ClothListActivity>()
        }
        codibook.setOnClickListener {
            Toast.makeText(applicationContext, "코디북은 아직 준비중이에요!", Toast.LENGTH_SHORT).show()
        }
        CredentialsManager.instance.activeUser.second!!.run {
            userNickName.text = nickname
            userEmail.text = email
        }
        settings.setOnClickListener {
            startActivity<SettingActivity>()
        }
        fusedLocationClient.lastLocation.addOnSuccessListener {
            if(it != null) initData(it)
            else {
                startLocationUpdates()
            }
        }
    }

    fun initData(location: Location) {
        CredentialsManager.instance.run {
            if (shouldUpdateWeather(System.currentTimeMillis())) {
                NetworkHelper.networkInstance.getWeather(location.latitude.toString(), location.longitude.toString()).enqueue(object : Callback<Weather> {
                    override fun onFailure(call: Call<Weather>?, t: Throwable?) {
                        Log.e("asdf", t!!.message)
                    }

                    override fun onResponse(call: Call<Weather>?, response: Response<Weather>?) {
                        when (response!!.code()) {
                            200 -> {
                                CredentialsManager.instance.weather = response.body()!!
                                CredentialsManager.instance.setLastUpdatedTime(System.currentTimeMillis())
                                configureWeather(response.body()!!)
                            }
                            else -> {
                                Toast.makeText(applicationContext, "날씨 정보를 받아올 수 없습니다.\n어플리케이션을 다시 시작해 보시고, 문제가 지속된다면 관리자에게 문의하세요.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                })
            } else configureWeather(weather!!)
        }


    }

    fun configureWeather(weather: Weather) {
        weather.run {
            var temp = current[0].replace("℃", "").toFloat()
            currentTemp.text = current[0]
            highLowTemp.text = "${todayTemps[1]}℃ / ${todayTemps[0]}℃"
            tempMessage.text = getTempMessage(this)
            clothByWeather.text = getClothMessage(temp)

            clothContainer.visibility = View.VISIBLE
            weatherContainer.visibility = View.VISIBLE
            clothProgress.visibility = View.GONE
            weatherProgress.visibility = View.GONE
            showWeather.setOnClickListener {
                startActivity<WeatherActivity>()
            }


        }
    }

    fun getTempMessage(weather: Weather): String {
        weather.run {
            if (ifItsSnowOrRainingToday(today) != "") {
                return if (ifItsSnowOrRainingToday(weather.today) == "비") "오늘 비 소식이 있어요. 우산 잊지 말아주세요." else "눈이 올 예정이에요. 길이 미끄러우니 엉덩방아 조심!"
            } else if (todayTemps[1].toInt() >= 26 && todayTemps[1].toInt() - todayTemps[0].toInt() >= 10) return "일교차가 심해요. 감기 조심하세요!"
            else if (Math.round(uvValue / 2) >= 7) return "자외선 지수가 너무 높아요. 자외선 차단제와 선글라스는 필수!!"
            else if (pm10 > 50) return "미세먼지로 가득찬 하늘, 마스크를 잊지마세요!"
            else {
                val average = (todayTemps[0].toInt() + todayTemps[1].toInt()) / 2F
                return when {
                    average >= 29 -> "무더운 하루에요. 낮에 야외활동을 주의하세요."
                    average in 23..28 -> "따사로운 햇살, 좋은하루 되세요!"
                    average in 18..22 -> "시원한 오늘! 잠깐 산책 어때요?"
                    average in 12..17 -> "쌀쌀한 날씨. 가벼운 외투를 챙겨주세요!"
                    average in 5..11 -> "추워요!"
                    average in 0..4 -> "너무 추워요!"
                    else -> "콧물도 얼어버릴 것 같은 오늘, 목도리와 모자로 체온을 지켜주세요."
                }
            }
        }
    }
    fun ifItsSnowOrRainingToday(today: ArrayList<Today>): String {
        for (i in today) {
            i.wfKor.run {
                if (this.contains("비")) return "비"
                else if (this.contains("눈")) return "눈"
            }
            if (i.hour == 24) break
        }
        return ""
    }


    fun getClothMessage(currentTemp: Float): String {
        return if (currentTemp > 27) "나시티, 반팔티, 반바지, 민소매 원피스"
        else if (currentTemp > 23) "반팔티, 얇은 셔츠, 반바지, 반팔 원피스"
        else if (currentTemp > 20) "긴팔티, 가디건, 면바지, 슬랙스"
        else if (currentTemp > 17) "가디건, 후드티, 청바지, 긴팔 원피스"
        else if (currentTemp > 12) "자켓, 셔츠, 가디건, 맨투맨"
        else if (currentTemp > 10) "트렌치코트, 야상, 니트"
        else if (currentTemp > 6) "코트, 무스탕, 니트, 부츠"
        else "패팅, 두꺼운 코트, 목도리"
    }

}
