package com.wooin95.otzzang.util

import android.widget.EditText

fun EditText.isEmpty() : Boolean{
    return this.text.toString().trim() == ""
}