package com.wooin95.otzzang.model

data class HashTag(
        var tag : String,
        var clothTokens : ArrayList<Cloth>
)


