package com.wooin95.otzzang.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class Cloth(
        var _id : String,
        var clothToken : String,
        var name : String,
        var weather : ArrayList<Int>,
        var clothType : Int,
        var usertoken : String,
        var hashTag : ArrayList<String>,
        @SerializedName("imageName") var imageUrl : String
) : Serializable

