package com.wooin95.otzzang

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Toast
import com.wooin95.otzzang.model.User
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_splash.*
import org.jetbrains.anko.startActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SplashActivity : BaseActivity() {

    override fun setDefault() {


        CredentialsManager.instance.activeUser.run {
            if (first!!) {
                NetworkHelper.networkInstance.autoLogin(second!!.token).enqueue(object : Callback<User>{
                    override fun onFailure(call: Call<User>?, t: Throwable?) {
                        initUI()
                    }

                    override fun onResponse(call: Call<User>?, response: Response<User>?) {
                        when(response!!.code()){
                            200 -> {
                                var body = response.body()!!
                                CredentialsManager.instance.setUser(body)
                                Toast.makeText(applicationContext, "${body.nickname} 님 환영합니다!", Toast.LENGTH_SHORT).show()
                                Handler().postDelayed({
                                    startActivity<MainActivity>()
                                    finish()
                                }, 1000)
                            }
                            else ->{
                                Toast.makeText(applicationContext, "세션이 만료되었습니다. 다시 로그인해주세요", Toast.LENGTH_SHORT).show()
                                initUI()
                            }
                        }
                    }
                })
            } else initUI()
        }
        login.setOnClickListener {
            startActivity<LoginActivity>()
        }
        register.setOnClickListener {
            startActivity<RegisterActivity>()
        }
    }

    private fun initUI(){
        buttonContainer.visibility = View.VISIBLE
    }

    override val viewId: Int = R.layout.activity_splash
    override val toolbarId: Int = 0
}
