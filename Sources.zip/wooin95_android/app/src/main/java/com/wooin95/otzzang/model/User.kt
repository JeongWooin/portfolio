package com.wooin95.otzzang.model

data class User(
        var _id : String,
        var token : String,
        var email : String,
        var password : String,
        var nickname : String,
        var name : String,
        var birthYear : String,
        var sex : String,
        var height : Int,
        var weight : Int
)


