package com.wooin95.otzzang.util


/**
 * Created by Junseok Oh on 2017-07-18.
 */

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.support.v4.util.Pair
import android.util.Log
import com.google.gson.Gson
import com.wooin95.otzzang.model.User
import com.wooin95.otzzang.model.Weather


class CredentialsManager private constructor() {
    private val preferences: SharedPreferences
    private val editor: SharedPreferences.Editor
    private val context: Context = AppController.context!!

    /* Credential Data */

    val activeUser: Pair<Boolean, User>
        get() {
            preferences.getString("user_json", "").run {
                return if (this.isNotEmpty()) {
                    Pair.create(true, Gson().fromJson(this, User::class.java))
                } else
                    Pair.create(false, null)
            }
        }

    fun setUser(user: User) {
        editor.putString("user_json", Gson().toJson(user, User::class.java)).apply()
    }

    var weather: Weather?
        get() {
            preferences.getString("weather_json", "").run {
                return if (isNotEmpty()) {
                    Gson().fromJson(this, Weather::class.java)
                } else null
            }
        }
        set(value) = editor.putString("weather_json", Gson().toJson(value, Weather::class.java)).apply()

    var notification : Boolean
        get() = preferences.getBoolean("notification", true)
        set(value) = editor.putBoolean("notification", value).apply()
    var mondayV: Boolean
        get() = preferences.getBoolean("monday", true)
        set(value) = editor.putBoolean("monday", value).apply()
    var tuesdayV : Boolean
        get() = preferences.getBoolean("tuesday", true)
        set(value) = editor.putBoolean("tuesday", value).apply()
    var wednesdayV : Boolean
        get() = preferences.getBoolean("wednesday", true)
        set(value) = editor.putBoolean("wednesday", value).apply()
    var thursdayV : Boolean
        get() = preferences.getBoolean("thursday", true)
        set(value) = editor.putBoolean("thursday", value).apply()
    var fridayV : Boolean
        get() = preferences.getBoolean("friday", true)
        set(value) = editor.putBoolean("friday", value).apply()
    var saturdayV : Boolean
        get() = preferences.getBoolean("saturday", true)
        set(value) = editor.putBoolean("saturday", value).apply()
    var sundayV : Boolean
        get() = preferences.getBoolean("sunday", true)
        set(value) = editor.putBoolean("sunday", value).apply()

    var soundV : Boolean
        get() = preferences.getBoolean("sound", true)
        set(value) = editor.putBoolean("sound", value).apply()

    var vibrateV : Boolean
        get() = preferences.getBoolean("vibrate", true)
        set(value) = editor.putBoolean("vibrate", value).apply()

    var notiHour : Int
        get() = preferences.getInt("notiHour", 9)
        set(value) = editor.putInt("notiHour", value).apply()

    var notiMin : Int
        get() = preferences.getInt("notiMin", 0)
        set(value) = editor.putInt("notiMin", value).apply()


    fun setLastUpdatedTime(time: Long) {
        editor.putLong("last_time", time).apply()
    }

    fun shouldUpdateWeather(time: Long): Boolean {
        val result = ((time - preferences.getLong("last_time", 0)) / 60000 > 10L)
        return result
    }

    fun isShownIn23hours(time : Long) : Boolean{
        val result = ((time - preferences.getLong("last_alarm_time", 0)) / 60000 < 1380L)
        return result
    }

    fun setLastAlarmTime(time: Long) {
        editor.putLong("last_alarm_time", time).apply()
    }

    fun clearAlarmTime() {
        editor.remove("last_alarm_time").apply()
    }

    init {
        preferences = context.getSharedPreferences("wooin95", Context.MODE_PRIVATE)
        editor = preferences.edit()
    }

    fun save(key: String, data: String) {
        editor.putString(key, data)
        editor.apply()
    }

    fun removeAllData() {
        editor.clear()
        editor.apply()
    }

    fun getString(key: String): String {
        return preferences.getString(key, "")
    }

    fun getInt(key: String): Int {
        return preferences.getInt(key, 0)
    }

    fun getBoolean(key: String): Boolean {
        return preferences.getBoolean(key, false)
    }

    fun getLong(key: String): Long {
        return preferences.getLong(key, 0)
    }

    companion object {

        /* Data Keys */
        @SuppressLint("StaticFieldLeak")
        private var manager: CredentialsManager? = null

        val instance: CredentialsManager
            get() {
                if (manager == null) manager = CredentialsManager()
                return manager as CredentialsManager
            }
    }

}