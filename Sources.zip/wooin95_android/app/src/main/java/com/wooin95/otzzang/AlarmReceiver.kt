package com.wooin95.otzzang

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.location.Location
import android.media.RingtoneManager
import android.os.Looper
import android.support.v4.app.NotificationCompat
import android.util.Log
import com.google.android.gms.location.*
import com.wooin95.otzzang.model.Today
import com.wooin95.otzzang.model.Weather
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.NetworkHelper
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class AlarmReceiver : BroadcastReceiver() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var mLocationRequest: LocationRequest? = null

    private val UPDATE_INTERVAL = (10 * 1000).toLong()  /* 10 secs */
    private val FASTEST_INTERVAL: Long = 2000 /* 2 sec */

    private var p0: Context? = null

    override fun onReceive(p0: Context?, p1: Intent?) {
        this.p0 = p0
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(p0!!)
        fusedLocationClient.lastLocation.addOnSuccessListener {
            if (it != null) initData(it)
            else {
                startLocationUpdates()
            }
        }
    }

    // Trigger new location updates at interval
    @SuppressLint("MissingPermission")
    protected fun startLocationUpdates() {

        // Create the location request to start receiving updates
        mLocationRequest = LocationRequest()
        mLocationRequest!!.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        mLocationRequest!!.interval = UPDATE_INTERVAL
        mLocationRequest!!.fastestInterval = FASTEST_INTERVAL

        val builder = LocationSettingsRequest.Builder()
        builder.addLocationRequest(mLocationRequest!!)
        val locationSettingsRequest = builder.build()

        val settingsClient = LocationServices.getSettingsClient(p0!!)
        settingsClient.checkLocationSettings(locationSettingsRequest)

        fusedLocationClient.requestLocationUpdates(mLocationRequest, object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult?) {
                initData(locationResult!!.lastLocation)
            }
        }, Looper.myLooper())
    }

    fun initData(location: Location) {
        CredentialsManager.instance.run {
            if (mustShowAlarmToday()) {
                if (shouldUpdateWeather(System.currentTimeMillis())) {
                    NetworkHelper.networkInstance.getWeather(location.latitude.toString(), location.longitude.toString()).enqueue(object : Callback<Weather> {
                        override fun onFailure(call: Call<Weather>?, t: Throwable?) {
                            Log.e("asdf2", t!!.message)
                        }

                        override fun onResponse(call: Call<Weather>?, response: Response<Weather>?) {
                            when (response!!.code()) {
                                200 -> {
                                    CredentialsManager.instance.weather = response.body()!!
                                    CredentialsManager.instance.setLastUpdatedTime(System.currentTimeMillis())
                                    ringAlarm(response.body()!!)
                                }
                                else -> {
                                    Log.e("asdf2", response.message())
                                }
                            }
                        }
                    })
                } else ringAlarm(weather!!)
            }
        }
    }

    fun mustShowAlarmToday(): Boolean {
        CredentialsManager.instance.run {
            if (isShownIn23hours(System.currentTimeMillis())) return false
            else if (!notification) return false
            else {
                val calendar = Calendar.getInstance()
                calendar.timeInMillis = System.currentTimeMillis()
                if (calendar.get(Calendar.HOUR_OF_DAY) != notiHour || Math.abs(calendar.get(Calendar.MINUTE) - notiMin) > 3) return false

                val day = calendar.get(Calendar.DAY_OF_WEEK)
                return when (day) {
                    1 -> sundayV
                    2 -> mondayV
                    3 -> tuesdayV
                    4 -> wednesdayV
                    5 -> thursdayV
                    6 -> fridayV
                    7 -> saturdayV
                    else -> false
                }
            }
        }
    }

    fun ringAlarm(weather: Weather) {
        val intent = Intent(p0, WeatherActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(p0, 0, intent, PendingIntent.FLAG_ONE_SHOT)

        val largeIcon = BitmapFactory.decodeResource(p0!!.resources, R.mipmap.ic_launcher)
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val notificationBuilder = NotificationCompat.Builder(p0!!, "wooin950")
                .setLargeIcon(largeIcon)
                .setContentTitle("${weather.todayTemps[1]}℃ / ${weather.todayTemps[0]}℃")
                .setContentText(getContentText(weather))
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setChannelId("wooin950")
                .setContentIntent(pendingIntent)
                .setSmallIcon(R.mipmap.ic_launcher)
        CredentialsManager.instance.run {
            if (!vibrateV && !soundV) {
                notificationBuilder
                        .setDefaults(Notification.DEFAULT_LIGHTS)
                        .setSound(null)
                        .setVibrate(null)
            } else if (!vibrateV) {
                notificationBuilder
                        .setDefaults(Notification.DEFAULT_SOUND)
                        .setVibrate(null)
            } else if (!soundV) {
                // !soundV
                notificationBuilder
                        .setDefaults(Notification.DEFAULT_VIBRATE)
                        .setSound(null)
            } else {
                notificationBuilder
                        .setDefaults(Notification.DEFAULT_ALL)
            }
        }
        val notificationManager = p0!!.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        notificationManager.notify(12034, notificationBuilder.build())
        CredentialsManager.instance.setLastAlarmTime(System.currentTimeMillis())
    }

    fun getContentText(weather: Weather): String {
        weather.run {
            if (ifItsSnowOrRainingToday(today) != "") {
                return if (ifItsSnowOrRainingToday(weather.today) == "비") "오늘 비 소식이 있어요. 우산 잊지 말아주세요." else "눈이 올 예정이에요. 길이 미끄러우니 엉덩방아 조심!"
            } else if (todayTemps[1].toInt() >= 26 && todayTemps[1].toInt() - todayTemps[0].toInt() >= 10) return "일교차가 심해요. 감기 조심하세요!"
            else if (Math.round(uvValue / 2) >= 7) return "자외선 지수가 너무 높아요. 자외선 차단제와 선글라스는 필수!!"
            else if (pm10 > 50) return "미세먼지로 가득찬 하늘, 마스크를 잊지마세요!"
            else {
                val average = (todayTemps[0].toInt() + todayTemps[1].toInt()) / 2F
                Log.e("asdf", average.toString())
                return when {
                    average >= 29 -> "무더운 하루에요. 낮에 야외활동을 주의하세요."
                    average in 23..28 -> "따사로운 햇살, 좋은하루 되세요!"
                    average in 18..22 -> "시원한 오늘! 잠깐 산책 어때요?"
                    average in 12..17 -> "쌀쌀한 날씨. 가벼운 외투를 챙겨주세요!"
                    average in 5..11 -> "추워요!"
                    average in 0..4 -> "너무 추워요!"
                    else -> "콧물도 얼어버릴 것 같은 오늘, 목도리와 모자로 체온을 지켜주세요."
                }
            }
        }
    }

    fun ifItsSnowOrRainingToday(today: ArrayList<Today>): String {
        for (i in today) {
            i.wfKor.run {
                if (this.contains("비")) return "비"
                else if (this.contains("눈")) return "눈"
            }
            if (i.hour == 24) break
        }
        return ""
    }
}

