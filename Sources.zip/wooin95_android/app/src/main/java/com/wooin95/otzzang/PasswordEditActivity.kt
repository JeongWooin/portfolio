package com.wooin95.otzzang

import android.util.Log
import android.widget.Toast
import com.wooin95.otzzang.model.User
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.EditTextUtils
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_edit_password.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PasswordEditActivity : BaseActivity() {

    override fun setDefault() {
        toolbarTitle = "비밀번호 수정"

        confirm.setOnClickListener {
            if (EditTextUtils.isFullFilled(passwordInput, passwordInputNew, passwordInputNewRe)) {
                val pw = passwordInput.text.toString()
                val newPw = passwordInputNew.text.toString()
                val newPwRe = passwordInputNewRe.text.toString()
                when {
                    pw != CredentialsManager.instance.activeUser.second!!.password -> Toast.makeText(applicationContext, "기존 비밀번호를 올바르게 입력해주세요.", Toast.LENGTH_SHORT).show()
                    newPw != newPwRe -> Toast.makeText(applicationContext, "새로운 비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show()
                    else -> NetworkHelper.networkInstance.editUserPassword(
                            CredentialsManager.instance.activeUser.second!!.token,
                            pw, newPw
                    ).enqueue(object : Callback<User> {
                        override fun onFailure(call: Call<User>?, t: Throwable?) {
                            Log.e("asdf", t!!.localizedMessage)
                        }

                        override fun onResponse(call: Call<User>?, response: Response<User>) {
                            when (response.code()) {
                                200 -> {
                                    Toast.makeText(applicationContext, "비밀번호 수정이 정상적으로 완료되었습니다.", Toast.LENGTH_SHORT).show()
                                    CredentialsManager.instance.setUser(response.body()!!)
                                    finish()
                                }
                                401 -> {
                                    Toast.makeText(applicationContext, "관리자에게 문의해주세요.", Toast.LENGTH_SHORT).show()
                                }
                                else -> {
                                    Log.e("asdf", response.message())
                                }
                            }
                        }
                    })
                }
            } else Toast.makeText(applicationContext, "빈칸 없이 입력해주세요!", Toast.LENGTH_SHORT).show()
        }
    }

    override val viewId: Int = R.layout.activity_edit_password
    override val toolbarId: Int = R.id.toolbar

}
