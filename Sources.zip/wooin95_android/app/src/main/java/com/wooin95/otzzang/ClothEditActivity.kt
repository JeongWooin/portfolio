package com.wooin95.otzzang

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.CheckBox
import android.widget.Toast
import com.afollestad.materialdialogs.MaterialDialog
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.cunoraz.tagview.Tag
import com.wooin95.otzzang.model.Cloth
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.NetworkHelper
import gun0912.tedbottompicker.TedBottomPicker
import kotlinx.android.synthetic.main.activity_cloth_edit.*
import okhttp3.MediaType
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class ClothEditActivity : BaseActivity() {

    val fromIntent by lazy { intent }
    val item: Cloth by lazy { fromIntent.getSerializableExtra("item") as Cloth }
    var imageUri: Uri? = null
    var REQUEST_CODE = 6977;
    var originHashTag = ArrayList<String>()
    var tagList = ArrayList<String>()
    lateinit var dialog: MaterialDialog
    val weatherButtonArray by lazy { arrayListOf<CheckBox>(weather0, weather1, weather2) }

    override fun setDefault() {
        toolbarTitle = "옷 편집"
        initView()
    }

    private fun initView() {
        titleInput.setText(item.name)
        clothTypeSpinner.setSelection(item.clothType)
        for (i in item.weather) {
            weatherButtonArray[i].isChecked = true
        }
        if (item.hashTag != null) {
            originHashTag.addAll(item.hashTag)
            tagList.addAll(item.hashTag)
        }
        for (i in tagList) {
            tagView.addTag(Tag(i))
        }
        Glide.with(this@ClothEditActivity)
                .load("${NetworkHelper.url}:${NetworkHelper.port}/images/${item.imageUrl}")
                .apply(RequestOptions().centerCrop())
                .into(photoItemImage)
        photoEdit.setOnClickListener { it ->
            TedBottomPicker.Builder(this@ClothEditActivity)
                    .setOnImageSelectedListener {
                        imageUri = it
                        Glide.with(this@ClothEditActivity)
                                .load(File(it.path))
                                .apply(RequestOptions().centerCrop())
                                .into(photoItemImage)
                    }
                    .create().show(supportFragmentManager)

        }
        addTag.setOnClickListener {
            startActivityForResult(Intent(applicationContext, HashTagControlActivity::class.java), REQUEST_CODE)
        }

        tagView.setOnTagClickListener { tag: Tag?, i: Int ->
            tagView.remove(i)
            tagList.removeAt(i)
        }
        confirm.setOnClickListener {
            dialog = MaterialDialog.Builder(this@ClothEditActivity)
                    .title("업로드를 진행중입니다.")
                    .progress(true, 0)
                    .cancelable(false)
                    .content("잠시만 기다려주세요")
                    .show()
            editPost()
        }
    }

    private fun editPost() {
        val titleStr = titleInput.text.toString().trim()
        when (titleStr) {
            "" -> {
                if (dialog.isShowing) dialog.dismiss()
                Toast.makeText(applicationContext, "이름을 입력해주세요", Toast.LENGTH_SHORT).show()
            }
            else -> {
                NetworkHelper.networkInstance.editCloth(
                        item._id,
                        item.clothToken,
                        CredentialsManager.instance.activeUser.second!!.token,
                        titleStr,
                        getSelectedWeather(),
                        clothTypeSpinner.selectedItemPosition,
                        tagList,
                        originHashTag
                ).enqueue(object : Callback<Cloth> {
                    override fun onFailure(call: Call<Cloth>?, t: Throwable?) {
                        Log.e("registerPost", t!!.localizedMessage)
                    }

                    override fun onResponse(call: Call<Cloth>?, response: Response<Cloth>?) {
                        val state = response!!.code()
                        when (state) {
                            200 -> {
                                if (imageUri != null) uploadFile(response.body()!!.clothToken)
                                else {
                                    if (dialog.isShowing) dialog.dismiss()
                                    Toast.makeText(applicationContext, "성공적으로 편집이 완료되었습니다!", Toast.LENGTH_SHORT).show()
                                    finishActivity(response.body()!!)
                                }
                            }
                            else -> {
                                Log.e("registerPost", response.message())
                            }
                        }
                    }
                })
            }
        }
    }

    private fun uploadFile(clothToken: String) {
        val imageFile = File(imageUri!!.encodedPath)
        val imageBody = RequestBody.create(MediaType.parse("image/png"), imageFile)

        NetworkHelper.networkInstance.editClothFile(
                RequestBody.create(MediaType.parse("text/plain"), clothToken),
                RequestBody.create(MediaType.parse("text/plain"), CredentialsManager.instance.activeUser.second!!.token),
                imageBody
        ).enqueue(object : Callback<Cloth> {
            override fun onFailure(call: Call<Cloth>?, t: Throwable?) {
                Log.e("uploadFile", t!!.localizedMessage)
            }

            override fun onResponse(call: Call<Cloth>?, response: Response<Cloth>?) {
                when (response!!.code()) {
                    200 -> {
                        if (dialog.isShowing) dialog.dismiss()
                        Toast.makeText(applicationContext, "성공적으로 업로드가 완료되었습니다!", Toast.LENGTH_SHORT).show()
                        finishActivity(response.body()!!)
                    }
                    else -> {
                        Log.e("uploadFile", response.message())
                    }
                }
            }
        })
    }

    private fun getSelectedWeather(): ArrayList<Int> {
        val result = arrayListOf<Int>()
        for (i in weatherButtonArray.indices) {
            if (weatherButtonArray[i].isChecked) result.add(i)
        }
        return result
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                val result = data!!.getStringExtra("result")
                if (tagList.size == 0 || !tagList.contains(result)) {
                    tagList.add(result)
                    tagView.addTag(Tag(result))
                } else Toast.makeText(applicationContext, "이미 추가된 해시태그입니다", Toast.LENGTH_SHORT).show()
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun finishActivity(item: Cloth) {
        setResult(Activity.RESULT_OK, fromIntent)
        fromIntent.putExtra("item", item)
        finish()
    }

    override val viewId: Int = R.layout.activity_cloth_edit
    override val toolbarId: Int = R.id.toolbar

}
