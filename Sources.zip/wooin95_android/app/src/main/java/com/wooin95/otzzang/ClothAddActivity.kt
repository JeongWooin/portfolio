package com.wooin95.otzzang

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.CheckBox
import android.widget.Toast
import com.afollestad.materialdialogs.MaterialDialog
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.cunoraz.tagview.Tag
import com.wooin95.otzzang.model.Cloth
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.NetworkHelper
import gun0912.tedbottompicker.TedBottomPicker
import kotlinx.android.synthetic.main.activity_cloth_add.*
import okhttp3.MediaType
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File

class ClothAddActivity : BaseActivity() {
    var imageUri: Uri? = null
    var REQUEST_CODE = 6977;
    var tagList = ArrayList<String>()
    lateinit var dialog : MaterialDialog
    val weatherButtonArray by lazy { arrayListOf<CheckBox>(weather0, weather1, weather2) }
    override fun setDefault() {
        toolbarTitle = "옷 등록"
        photoEdit.setOnClickListener { it ->
            TedBottomPicker.Builder(this@ClothAddActivity)
                    .setOnImageSelectedListener {
                        imageUri = it
                        Glide.with(this@ClothAddActivity)
                                .load(File(it.path))
                                .apply(RequestOptions().centerCrop())
                                .into(photoItemImage)
                    }
                    .create().show(supportFragmentManager)

        }
        addTag.setOnClickListener {
            startActivityForResult(Intent(applicationContext, HashTagControlActivity::class.java), REQUEST_CODE)
        }

        tagView.setOnTagClickListener { tag: Tag?, i: Int ->
            tagView.remove(i)
            tagList.removeAt(i)
        }
        confirm.setOnClickListener {
            dialog = MaterialDialog.Builder(this@ClothAddActivity)
                    .title("업로드를 진행중입니다.")
                    .cancelable(false)
                    .progress(true, 0)
                    .content("잠시만 기다려주세요")
                    .show()
            registerPost()
        }

    }

    private fun registerPost() {
        val titleStr = titleInput.text.toString().trim()
        when {
            titleStr == "" -> {
                if(dialog.isShowing) dialog.dismiss()
                Toast.makeText(applicationContext, "이름을 입력해주세요", Toast.LENGTH_SHORT).show()
            }
            imageUri == null -> {
                if(dialog.isShowing) dialog.dismiss()
                Toast.makeText(applicationContext, "사진을 추가해주세요", Toast.LENGTH_SHORT).show()
            }
            else -> {
                NetworkHelper.networkInstance.newCloth(
                        CredentialsManager.instance.activeUser.second!!.token,
                        titleStr,
                        getSelectedWeather(),
                        clothTypeSpinner.selectedItemPosition,
                        tagList
                ).enqueue(object : Callback<Cloth> {
                    override fun onFailure(call: Call<Cloth>?, t: Throwable?) {
                        Log.e("registerPost", t!!.localizedMessage)
                    }

                    override fun onResponse(call: Call<Cloth>?, response: Response<Cloth>?) {
                        val state = response!!.code()
                        when (state) {
                            200 -> {
                                uploadFile(response.body()!!.clothToken)
                            }
                            else -> {
                                Log.e("registerPost", response.message())
                            }
                        }
                    }
                })
            }
        }
    }

    private fun uploadFile(clothToken : String){
        val imageFile = File(imageUri!!.path)
        val imageBody = RequestBody.create(MediaType.parse("image/png"), imageFile)

        NetworkHelper.networkInstance.editClothFile(
                RequestBody.create(MediaType.parse("text/plain"), clothToken),
                RequestBody.create(MediaType.parse("text/plain"), CredentialsManager.instance.activeUser.second!!.token),
                imageBody
        ).enqueue(object : Callback<Cloth>{
            override fun onFailure(call: Call<Cloth>?, t: Throwable?) {
                Log.e("uploadFile", t!!.localizedMessage)
            }

            override fun onResponse(call: Call<Cloth>?, response: Response<Cloth>?) {
                when(response!!.code()){
                    200 -> {
                        if(dialog.isShowing) dialog.dismiss()
                        Toast.makeText(applicationContext, "성공적으로 업로드가 완료되었습니다!", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                    else -> {
                        Log.e("uploadFile", response.message())
                    }
                }
            }
        })
    }

    private fun getSelectedWeather() : ArrayList<Int>{
        val result = arrayListOf<Int>()
        for(i in weatherButtonArray.indices){
            if(weatherButtonArray[i].isChecked) result.add(i)
        }
        return result
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                val result = data!!.getStringExtra("result")
                if(!tagList.contains(result)) {
                    tagList.add(result)
                    tagView.addTag(Tag(result))
                }
                else Toast.makeText(applicationContext, "이미 추가된 해시태그입니다", Toast.LENGTH_SHORT).show()
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override val viewId: Int = R.layout.activity_cloth_add
    override val toolbarId: Int = R.id.toolbar
}
