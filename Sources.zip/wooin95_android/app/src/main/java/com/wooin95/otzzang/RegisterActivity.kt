package com.wooin95.otzzang

import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Toast
import com.wooin95.otzzang.model.User
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.EditTextUtils
import com.wooin95.otzzang.util.NetworkHelper
import com.wooin95.otzzang.util.isEmpty
import kotlinx.android.synthetic.main.activity_register.*
import okhttp3.ResponseBody
import org.jetbrains.anko.startActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class RegisterActivity : BaseActivity() {

    override fun setDefault() {
        toolbarTitle = "회원가입"
        val years = ArrayList<String>()
        val thisYear = Calendar.getInstance().get(Calendar.YEAR)
        for (i in 1950..thisYear) {
            years.add(Integer.toString(i))
        }
        val adapter = ArrayAdapter<String>(this@RegisterActivity, android.R.layout.simple_dropdown_item_1line, years)
        yearSpinner.adapter = adapter
        yearSpinner.setSelection(years.size - 1)
        confirm.setOnClickListener {
            if (EditTextUtils.isFullFilled(emailInput, passwordInput, passwordInputRe, nickNameInput)) {
                val height = if (heightInput.text.toString().trim() == "") 0 else heightInput.text.toString().toInt()
                val weight = if (weightInput.text.toString().trim() == "") 0 else weightInput.text.toString().toInt()
                if (!emailInput.text.toString().trim().contains("@")) {
                    Toast.makeText(applicationContext, "이메일 형식이 맞지 않습니다!", Toast.LENGTH_SHORT).show()
                } else if (passwordInput.text.toString().trim() != passwordInputRe.text.toString().trim()) {
                    Toast.makeText(applicationContext, "비밀번호가 일치하지 않습니다!", Toast.LENGTH_SHORT).show()
                } else {
                    NetworkHelper.networkInstance.register(
                            emailInput.text.toString().trim(),
                            passwordInput.text.toString().trim(),
                            nickNameInput.text.toString().trim(),
                            nameInput.text.toString().trim(),
                            yearSpinner.selectedItem.toString().toInt(),
                            sexSpinner.selectedItem.toString(),
                            height,
                            weight

                    ).enqueue(object : Callback<ResponseBody> {
                        override fun onFailure(call: Call<ResponseBody>?, t: Throwable?) {
                            Log.e("asdf", t!!.localizedMessage)
                        }

                        override fun onResponse(call: Call<ResponseBody>?, response: Response<ResponseBody>) {
                            when (response.code()) {
                                200 -> {
                                    Toast.makeText(applicationContext, "회원가입이 완료되었습니다! 로그인 해주세요.", Toast.LENGTH_SHORT).show()
                                    startActivity<LoginActivity>()
                                    finish()
                                }
                                409 -> {
                                    Toast.makeText(applicationContext, "이미 존재하는 메일 주소입니다!", Toast.LENGTH_SHORT).show()
                                }
                                else -> {
                                    Log.e("asdf", response.message())
                                }
                            }
                        }
                    })
                }
            } else Toast.makeText(applicationContext, getBlankFieldMessage(), Toast.LENGTH_SHORT).show()
        }
    }

    fun getBlankFieldMessage(): String {
        var sb = StringBuilder()
        var arr = arrayListOf(emailInput, passwordInput, passwordInputRe, nickNameInput)
        for (i in arr.indices) {
            if (arr[i].isEmpty()) {
                sb.append(when (i) {
                    0 -> "이메일"
                    1 -> "비밀번호"
                    2 -> "비밀번호 재입력"
                    else -> "닉네임"
                })
                sb.append(", ")
            }
        }
        sb.delete(sb.length - 2, sb.length)
        sb.append("을(를) 입력해주세요.")
        return sb.toString()
    }


    override val viewId: Int = R.layout.activity_register
    override val toolbarId: Int = R.id.toolbar

}
