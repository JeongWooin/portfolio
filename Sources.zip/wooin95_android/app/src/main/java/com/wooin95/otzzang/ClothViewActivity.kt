package com.wooin95.otzzang

import android.app.Activity
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.afollestad.materialdialogs.MaterialDialog
import com.bumptech.glide.Glide
import com.cunoraz.tagview.Tag
import com.wooin95.otzzang.model.Cloth
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_cloth_view.*
import okhttp3.ResponseBody
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.startActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ClothViewActivity : BaseActivity() {

    val REQUEST_CODE = 6978
    lateinit var item: Cloth
    val weatherArray = arrayListOf(
            "봄&가을", "여름", "겨울"
    )
    val hashTagArray = arrayListOf(
            "외투", "상의", "하의", "한 벌 옷", "신발", "악세사리", "선택 안함"
    )

    override fun setDefault() {
        toolbarTitle = "옷 보기"
        item = intent.getSerializableExtra("item") as Cloth
        initView()
    }

    private fun initView() {
        Glide.with(this@ClothViewActivity)
                .load("${NetworkHelper.url}:${NetworkHelper.port}/images/${item.imageUrl}")
                .into(itemImage)
        itemTitle.text = item.name
        itemContent.text = "계절 : ${getWeatherText()}\n옷 종류 : ${hashTagArray[item.clothType]}"
        if (item.hashTag != null) for (i in item.hashTag) {
            tagView.addTag(Tag(i))
        }
        edit.setOnClickListener {
            startActivityForResult(intentFor<ClothEditActivity>("item" to item), REQUEST_CODE)
        }
        delete.setOnClickListener {
            MaterialDialog.Builder(this@ClothViewActivity)
                    .title("옷 삭제")
                    .content("정말로 ${item.name}을 삭제하시겠어요?")
                    .positiveText("삭제")
                    .negativeText("취소")
                    .onPositive { dialog, which ->
                        removeItem()
                    }
                    .show()
        }
    }

    private fun getWeatherText() : String{
        val sb = StringBuilder()
        for(i in item.weather){
            sb.append(weatherArray[i])
            sb.append(", ")
        }
        sb.delete(sb.length -2, sb.length)
        return sb.toString()
    }

    private fun removeItem() {
        NetworkHelper.networkInstance.removeCloth(
                item._id,
                item.clothToken,
                CredentialsManager.instance.activeUser.second!!.token
        ).enqueue(object : Callback<ResponseBody> {
            override fun onFailure(call: Call<ResponseBody>?, t: Throwable?) {
                Log.e("asdf", t!!.localizedMessage)
            }

            override fun onResponse(call: Call<ResponseBody>?, response: Response<ResponseBody>?) {
                val state = response!!.code()

                when (state) {
                    200 -> {
                        Toast.makeText(applicationContext, "옷이 삭제되었어요.", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                    else -> {
                        Log.e("asdf", response.message())
                    }
                }
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            item = data!!.getSerializableExtra("item") as Cloth
            tagView.removeAll()
            initView()
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override val viewId: Int = R.layout.activity_cloth_view
    override val toolbarId: Int = R.id.toolbar

}
