package com.wooin95.otzzang

import android.util.Log
import android.widget.Toast
import com.wooin95.otzzang.model.User
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.EditTextUtils
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_login.*
import org.jetbrains.anko.clearTask
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.newTask
import org.jetbrains.anko.startActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : BaseActivity() {
    override fun setDefault() {
        login.setOnClickListener {
            if(EditTextUtils.isFullFilled(emailInput, passwordInput)){
                NetworkHelper.networkInstance.login(
                        emailInput.text.toString().trim(),
                        passwordInput.text.toString().trim()
                ).enqueue(object : Callback<User>{
                    override fun onFailure(call: Call<User>?, t: Throwable?) {
                        Log.e("asdf", t!!.localizedMessage)
                    }

                    override fun onResponse(call: Call<User>?, response: Response<User>) {
                        when(response.code()){
                            200 -> {
                                Toast.makeText(applicationContext, "${response.body()!!.nickname} 님 환영합니다!", Toast.LENGTH_SHORT).show()
                                CredentialsManager.instance.setUser(response.body()!!)
                                startActivity(intentFor<MainActivity>().clearTask().newTask())
                            }
                            401 -> {
                                Toast.makeText(applicationContext, "아이디 혹은 비밀번호가 잘못되었습니다!", Toast.LENGTH_SHORT).show()
                            }
                            else -> {
                                Log.e("asdf", response.message())
                            }
                        }
                    }
                })
            }
        }

    }

    override val viewId: Int = R.layout.activity_login
    override val toolbarId: Int =0

}
