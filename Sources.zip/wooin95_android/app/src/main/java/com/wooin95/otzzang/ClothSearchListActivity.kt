package com.wooin95.otzzang

import android.support.v7.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.RequestManager
import com.github.nitrico.lastadapter.LastAdapter
import com.wooin95.otzzang.databinding.ContentSearchItemBinding
import com.wooin95.otzzang.model.Cloth
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_cloth_search_list.*
import org.jetbrains.anko.intentFor

class ClothSearchListActivity : BaseActivity() {

    private val imageRequestManager: RequestManager by lazy { Glide.with(this) }

    val itemArray = ArrayList<Cloth>()
    val itemAdapter by lazy {
        LastAdapter(itemArray, BR.content)
    }

    override fun setDefault() {
        toolbarTitle = "#${intent.getStringExtra("query")}"
        itemArray.addAll(intent.getSerializableExtra("cloths") as ArrayList<Cloth>)
        initView()
        getData()
    }

    private fun initView() {
        GridLayoutManager(this@ClothSearchListActivity, 2).run {
            clothListRecyclerView.layoutManager = this
        }

        itemAdapter
                .map<Cloth, ContentSearchItemBinding>(R.layout.content_search_item) {
                    onBind {
                        val item = itemArray[it.adapterPosition]
                        imageRequestManager
                                .load("${NetworkHelper.url}:${NetworkHelper.port}/images/${item.imageUrl}")
                                .into(it.binding.image)
                    }
                    onClick {
                        val item = itemArray[it.adapterPosition]
                        startActivity(intentFor<ClothViewActivity>("item" to item))
                        finish()
                    }
                }
                .into(clothListRecyclerView)

    }

    private fun getData() {
        itemAdapter.notifyItemRangeChanged(0, itemArray.size)
        itemAdapter.notifyDataSetChanged()
    }

    override val viewId: Int = R.layout.activity_cloth_search_list
    override val toolbarId: Int = R.id.toolbar
}
