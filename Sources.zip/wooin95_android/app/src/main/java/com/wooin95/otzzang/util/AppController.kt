package com.wooin95.otzzang.util

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import com.wooin95.otzzang.AlarmReceiver
import com.wooin95.otzzang.R
import java.util.*

class AppController : Application() {

    val alarmMgr: AlarmManager by lazy { AppController.context!!.getSystemService(Context.ALARM_SERVICE) as AlarmManager }
    lateinit var alarmIntent: PendingIntent

    override fun onCreate() {
        super.onCreate()
        context = applicationContext

        alarmIntent = Intent(this, AlarmReceiver::class.java).let { intent ->
            PendingIntent.getBroadcast(this, 0, intent, 0)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !getSharedPreferences("wooin95", 0).getBoolean("isOReady", false)) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            val channelMessage = NotificationChannel("wooin950", "옷쨩", NotificationManager.IMPORTANCE_DEFAULT)
            channelMessage.enableLights(true)
            channelMessage.lightColor = Color.BLUE
            channelMessage.enableVibration(true)
            channelMessage.vibrationPattern = longArrayOf(100, 200, 100, 200)
            channelMessage.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            notificationManager.createNotificationChannel(channelMessage)
            getSharedPreferences("wooin95", 0).edit().putBoolean("isOReady", true).apply()
        }
        if (!getSharedPreferences("wooin95", 0).getBoolean("isFirstAlarmSet", false)) setAlarm(9, 0)

    }

    private fun setAlarm(hour: Int, minute: Int) {
        val calendar: Calendar = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, 9)
            set(Calendar.MINUTE, 0)
        }
        alarmMgr.setRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                alarmIntent
        )
        getSharedPreferences("wooin95", 0).edit().putBoolean("isFirstAlarmSet", true).apply()
    }

    companion object {
        var context: Context? = null
    }
}