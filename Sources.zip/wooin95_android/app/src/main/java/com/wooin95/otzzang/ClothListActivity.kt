package com.wooin95.otzzang

import android.graphics.Color
import android.net.Network
import android.support.v7.widget.CardView
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import com.bumptech.glide.Glide
import com.bumptech.glide.RequestManager
import com.github.nitrico.lastadapter.LastAdapter
import com.wooin95.otzzang.databinding.ContentSearchHashtagBinding
import com.wooin95.otzzang.databinding.ContentSearchItemBinding
import com.wooin95.otzzang.model.Cloth
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_cloth_list.*
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.startActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ClothListActivity : BaseActivity() {

    private val imageRequestManager: RequestManager by lazy { Glide.with(this) }
    val weatherArray = arrayListOf(
            Selectable(true, "전체"), Selectable(false, "봄&가을"), Selectable(false, "여름"), Selectable(false, "겨울")
    )
    val hashTagArray = arrayListOf(
            Selectable(true, "전체"),
            Selectable(false, "외투"),
            Selectable(false, "상의"),
            Selectable(false, "하의"),
            Selectable(false, "한 벌 옷"),
            Selectable(false, "신발"),
            Selectable(false, "악세사리")
    )
    val hashTagAdapter by lazy {
        LastAdapter(hashTagArray, BR.content)
    }

    val itemArray = ArrayList<Cloth>()
    val itemAdapter by lazy {
        LastAdapter(itemArray, BR.content)
    }

    val weatherColorArray = arrayListOf("#EDB8B3", "#FFDF9D", "#96E6A5", "#A6D9FF")
    val weatherSelectedColorArray = arrayListOf("#ED5450", "#FFC927", "#0DE676", "#01B0FF")
    val weatherButtonArray by lazy { arrayListOf<CardView>(weatherAll, weather0, weather1, weather2) }
    var isLoaded = false

    override fun setDefault() {
        toolbarTitle = "내가 추가한 옷"
        initView()
        getData()
    }

    private fun initView() {
        addCloth.setOnClickListener {
            startActivity<ClothAddActivity>()
        }
        weatherAll.setOnClickListener {
            updateWeatherAndLocalData(0)
        }
        weather0.setOnClickListener {
            updateWeatherAndLocalData(1)
        }
        weather1.setOnClickListener {
            updateWeatherAndLocalData(2)
        }
        weather2.setOnClickListener {
            updateWeatherAndLocalData(3)
        }
        LinearLayoutManager(this@ClothListActivity).run {
            orientation = LinearLayout.HORIZONTAL
            clothTypeRecyclerView.layoutManager = this
        }
        GridLayoutManager(this@ClothListActivity, 2).run {
            clothListRecyclerView.layoutManager = this
        }
        hashTagAdapter
                .map<Selectable, ContentSearchHashtagBinding>(R.layout.content_search_hashtag) {
                    onBind {
                        val data = hashTagArray[it.adapterPosition]
                        it.binding.background.setBackgroundResource(
                                if (data.isSelected) R.drawable.bg_hashtag_selected else R.drawable.bg_hashtag
                        )
                    }
                    onClick {
                        val data = hashTagArray[it.adapterPosition]
//                        if (it.adapterPosition == 0) {
//                            for (i in hashTagArray.indices) {
//                                hashTagArray[i].isSelected = i == 0
//                            }
//                        } else {
//                            hashTagArray[0].isSelected = false
//                            data.isSelected = !data.isSelected
//                        }
                        for (i in hashTagArray.indices) {
                            hashTagArray[i].isSelected = i == it.adapterPosition
                        }
                        hashTagAdapter.notifyItemChanged(it.adapterPosition)
                        hashTagAdapter.notifyDataSetChanged()
                        getData()
                    }
                }
                .into(clothTypeRecyclerView)

        itemAdapter
                .map<Cloth, ContentSearchItemBinding>(R.layout.content_search_item) {
                    onBind {
                        val item = itemArray[it.adapterPosition]
                        imageRequestManager
                                .load("${NetworkHelper.url}:${NetworkHelper.port}/images/${item.imageUrl}")
                                .into(it.binding.image)
                    }
                    onClick {
                        val item = itemArray[it.adapterPosition]
                        startActivity(intentFor<ClothViewActivity>("item" to item))
                    }
                }
                .into(clothListRecyclerView)
        updateWeatherAndLocalData(0)
    }

    private fun updateWeatherAndLocalData(index: Int) {
        if (index == 0) {
            for (i in weatherArray.indices) {
                weatherArray[i].isSelected = i == 0
                weatherButtonArray[i].setCardBackgroundColor(Color.parseColor(getWeatherColor(i, i == 0)))
            }
        } else {
            weatherArray[index].isSelected = !weatherArray[index].isSelected
            weatherArray[0].isSelected = !isWeatherSelected()
            weatherButtonArray[0].setCardBackgroundColor(Color.parseColor(getWeatherColor(0, weatherArray[0].isSelected)))
            weatherButtonArray[index].setCardBackgroundColor(Color.parseColor(getWeatherColor(index, weatherArray[index].isSelected)))
        }
        getData()
    }

    private fun isWeatherSelected(): Boolean {
        for (i in weatherArray) {
            if (i.isSelected) return true
        }
        return false
    }

    private fun getWeatherColor(index: Int, isSelected: Boolean): String {
        return if (isSelected) weatherSelectedColorArray[index] else weatherColorArray[index]
    }

    private fun getData() {
        val currentWeather = arrayListOf<Int>()
        var currentClothType = -1
        for (i in weatherArray.indices) {
            val data = weatherArray[i]
            if (data.isSelected) {
                currentWeather.add(i - 1)
                if(i == 0) break
            }
        }
        for(i in hashTagArray.indices){
            if(hashTagArray[i].isSelected) {
                currentClothType = i-1
                break
            }
        }
        NetworkHelper.networkInstance.getClothList(
                CredentialsManager.instance.activeUser.second!!.token,
                currentWeather,
                currentClothType
        ).enqueue(object : Callback<ArrayList<Cloth>> {
            override fun onFailure(call: Call<ArrayList<Cloth>>?, t: Throwable?) {
                Log.e("asdf", t!!.localizedMessage)
            }

            override fun onResponse(call: Call<ArrayList<Cloth>>?, response: Response<ArrayList<Cloth>>?) {
                val code = response!!.code()
                when (code) {
                    200 -> {
                        Log.e("asdf", itemArray.size.toString())
                        isLoaded = true
                        itemArray.clear()
                        itemArray.addAll(response.body()!!)
                        itemAdapter.notifyItemRangeChanged(0, itemArray.size)
                        itemAdapter.notifyDataSetChanged()

                        searchStatusText.visibility = if (itemArray.size == 0) View.VISIBLE else View.GONE
                    }
                    else -> {
                        Log.e("asdf", response.message())
                        finish()
                    }
                }
            }
        })

    }

    override fun onResume() {
        super.onResume()
        if (isLoaded) getData()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.search) {
            startActivity<HashTagSearchActivity>()
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.clothlist, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override val viewId: Int = R.layout.activity_cloth_list
    override val toolbarId: Int = R.id.toolbar
}

data class Selectable(
        var isSelected: Boolean = false,
        var title: String
)
