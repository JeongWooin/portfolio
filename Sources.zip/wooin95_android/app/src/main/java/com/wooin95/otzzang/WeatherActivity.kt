package com.wooin95.otzzang

import android.location.Geocoder
import android.os.Build
import android.support.v4.view.ViewCompat
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.LinearLayout
import android.widget.Toast
import com.github.nitrico.lastadapter.LastAdapter
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.wooin95.otzzang.databinding.ContentCombinedWeekBinding
import com.wooin95.otzzang.databinding.ContentTodayBinding
import com.wooin95.otzzang.databinding.ContentWeekBinding
import com.wooin95.otzzang.model.CombinedWeek
import com.wooin95.otzzang.model.Today
import com.wooin95.otzzang.model.Weather
import com.wooin95.otzzang.model.Week
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.IconUtils
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_weather.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.collections.ArrayList

class WeatherActivity : BaseActivity() {

    var weather: Weather? = null
    var todayDatas = ArrayList<Today>()
    var weekDatas = ArrayList<Any>()

    val todayAdapter by lazy {
        LastAdapter(todayDatas, BR.content)
    }
    val weekAdapter by lazy {
        LastAdapter(weekDatas, BR.content)
    }

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun setDefault() {
        toolbarTitle = "날씨"
        weather = CredentialsManager.instance.weather!!
        val gCoder = Geocoder(applicationContext, Locale.getDefault())
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        initView()
        setTodayAdapter()
        setWeekAdapter()
    }

    private fun initView() {
        weather!!.run {
            val pm10StateText = getPm10StateText(pm10)
            locationAndTime.text = "$address\n${pubDate.replace("(", "").replace(")", "")} 기준"
            temperature.text = current[0]
            temperatureHighLow.text = getHighLow(todayTemps[1], todayTemps[0])
            currentOtherInfo.text = "${current[1]}\n${current[2]}\n미세먼지 지수 : $pm10StateText ($pm10)\n자외선 지수 : ${Math.round(uvValue / 2)}"
        }
    }

    private fun setTodayAdapter() {
        val manager = LinearLayoutManager(this@WeatherActivity)
        manager.orientation = LinearLayout.HORIZONTAL
        todayRecycler.layoutManager = manager
        setTodayContent()
        todayAdapter
                .map<Today, ContentTodayBinding>(R.layout.content_today) {
                    onBind {
                        it.binding.run {
                            val item = todayDatas[it.adapterPosition]
                            image.setImageResource(IconUtils.getIcon(item.wfKor, item.hour))
                            highLowText.text = item.temp.toString()
                            hourText.text = if (it.adapterPosition != 0) "${item.hour}시" else "지금"
                        }
                    }
                }
                .into(todayRecycler)
    }

    private fun setWeekAdapter() {
        val manager = LinearLayoutManager(this@WeatherActivity)
        manager.orientation = LinearLayout.VERTICAL
        weekRecycler.layoutManager = manager
        setWeekContent()
        weekAdapter
                .map<Week, ContentWeekBinding>(R.layout.content_week) {
                    onBind {
                        it.binding.run {
                            val item = weekDatas[it.adapterPosition] as Week
                            dateText.text = "${getDateFromTmEf(item)}일"
                            imageIcon.setImageResource(IconUtils.getIcon(item.wf, getHourFromTmEf(item)))
                            highLowText.text = "${String.format("%.1f", item.tmx.toFloat())}/${String.format("%.1f", item.tmn.toFloat())}"
                        }
                    }
                }
                .map<CombinedWeek, ContentCombinedWeekBinding>(R.layout.content_combined_week) {
                    onBind {
                        it.binding.run {
                            val item = weekDatas[it.adapterPosition] as CombinedWeek
                            dateText.text = "${getDateFromTmEf(item)}일"
                            imageIcon.setImageResource(IconUtils.getIcon(item.wf1, getHourFromTmEf(item)))
                            imageIcon2.setImageResource(IconUtils.getIcon(item.wf2, 12))
                            highLowText.text = "${String.format("%.1f", item.tmx)}/${String.format("%.1f", item.tmn)}"
                        }
                    }
                }

                .into(weekRecycler)
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
            weekRecycler.isNestedScrollingEnabled = false
        } else {
            ViewCompat.setNestedScrollingEnabled(weekRecycler, false)
        }
    }

    private fun setTodayContent() {
        todayDatas.add(
                Today(
                        -1,
                        Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
                        -1,
                        weather!!.current[0].replace("℃", "").toDouble(),
                        weather!!.currentTempMax.toDouble(),
                        weather!!.currentTempMin.toDouble(),
                        weather!!.today[0].wfKor
                )
        )
        for (i in weather!!.today.indices) {
            if (i < 8) todayDatas.add(weather!!.today[i])
            else break
        }
    }

    private fun setWeekContent() {
        weather!!.week.run {
            for (i in this.indices) {
                if (getHourFromTmEf(this[i]) != 0) continue
                else {
                    when {
                        i == this.size - 1 -> weekDatas.add(this[i])
                        getHourFromTmEf(this[i + 1]) == 0 -> weekDatas.add(this[i])
                        else -> weekDatas.add(CombinedWeek(
                                this[i].tmEf,
                                this[i].wf,
                                this[i + 1].wf,
                                (this[i].tmn + this[i + 1].tmn).toFloat() / 2F,
                                (this[i].tmx + this[i + 1].tmx).toFloat() / 2F
                        ))
                    }
                }
            }
            if (weekDatas.size >= 7) {
                weekDatas = weekDatas.slice(0..4) as ArrayList<Any>
            }
            weekDatas.add(0, makeWeekFromTodays())
        }
    }

    private fun makeWeekFromTodays(): CombinedWeek {
        val todays = weather!!.today.slice(8 until weather!!.today.size) as ArrayList
        return CombinedWeek(
                getPreviousDateFromTmEf(weather!!.week[0].tmEf),
                todays[0].wfKor,
                todays[todays.size / 2].wfKor,
                getLowTempFromTodays(todays),
                getHighTempFromTodays(todays)
        )
    }

    private fun getHighTempFromTodays(todays: ArrayList<Today>): Float {
        var max = -1F
        for (i in todays) {
            if (max < i.temp) max = i.temp.toFloat()
        }
        return max
    }

    private fun getLowTempFromTodays(todays: ArrayList<Today>): Float {
        var min = Float.MAX_VALUE
        for (i in todays) {
            if (min > i.temp) min = i.temp.toFloat()
        }
        return min
    }

    private fun getPreviousDateFromTmEf(tmEf: String): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).format(Date(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).parse(tmEf).time - TimeUnit.DAYS.toMillis(1)))
    }

    private fun getDateFromTmEf(item: Week): Int {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).parse(item.tmEf).time
        return calendar.get(Calendar.DAY_OF_MONTH)
    }

    private fun getHourFromTmEf(item: Week): Int {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).parse(item.tmEf).time
        return calendar.get(Calendar.HOUR_OF_DAY)
    }

    private fun getDateFromTmEf(item: CombinedWeek): Int {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).parse(item.tmEf).time
        return calendar.get(Calendar.DAY_OF_MONTH)
    }

    private fun getHourFromTmEf(item: CombinedWeek): Int {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).parse(item.tmEf).time
        return calendar.get(Calendar.HOUR_OF_DAY)
    }

    private fun getHighLow(currentMax: String, currentMin: String): String {
        return "최고온도 ${currentMax}℃ / 최저온도 ${currentMin}℃"
    }

    private fun getPm10StateText(pm10: Int): String {
        return when {
            pm10 == -1 -> "현재 미세먼지 지수를 가져올수 없습니다"
            pm10 > 151 -> "매우나쁨"
            pm10 > 80 -> "나쁨"
            pm10 > 30 -> "보통"
            else -> "좋음"
        }
    }

    private fun refreshData() {
        fusedLocationClient.run {
            lastLocation.addOnSuccessListener {
                if (it != null) {
                    NetworkHelper.networkInstance.getWeather(it.latitude.toString(), it.longitude.toString()).enqueue(object : Callback<Weather> {
                        override fun onFailure(call: Call<Weather>?, t: Throwable?) {
                            Log.e("asdf", t!!.message)
                        }

                        override fun onResponse(call: Call<Weather>?, response: Response<Weather>?) {
                            when (response!!.code()) {
                                200 -> {
                                    CredentialsManager.instance.weather = response.body()!!
                                    CredentialsManager.instance.setLastUpdatedTime(System.currentTimeMillis())
                                    weather = CredentialsManager.instance.weather!!
                                    initView()
                                }
                                else -> {
                                    Toast.makeText(applicationContext, "날씨 정보를 받아올 수 없습니다.\n어플리케이션을 다시 시작해 보시고, 문제가 지속된다면 관리자에게 문의하세요.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    })
                }

            }

        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.weather, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item!!.itemId) {
            R.id.refresh -> refreshData()
        }
        return super.onOptionsItemSelected(item)
    }

    override val viewId: Int = R.layout.activity_weather
    override val toolbarId: Int = R.id.toolbar
}
