package com.wooin95.otzzang.util

import android.content.Context
import android.net.ConnectivityManager
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Created by Junseok Oh on 2017-08-02.
 */

object NetworkHelper {
    public val url = "http://178.128.93.87"
    public val port = 8080

    private var retrofit: Retrofit? = null

    val networkInstance: NetworkInterface
        get() {
            if (retrofit == null) {
                retrofit = Retrofit.Builder()
                        .baseUrl("$url:$port")
                        .addConverterFactory(GsonConverterFactory.create())
                        .build()
            }
            return retrofit!!.create<NetworkInterface>(NetworkInterface::class.java)
        }

    fun returnNetworkState(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return connectivityManager.activeNetworkInfo != null && connectivityManager.activeNetworkInfo.isConnected
    }
}