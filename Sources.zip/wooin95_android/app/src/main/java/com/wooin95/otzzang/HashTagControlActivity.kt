package com.wooin95.otzzang

import android.app.Activity
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.LinearLayoutManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.LinearLayout
import android.widget.Toast
import com.afollestad.materialdialogs.MaterialDialog
import com.github.nitrico.lastadapter.LastAdapter
import com.wooin95.otzzang.databinding.ContentHashtagHeaderBinding
import com.wooin95.otzzang.databinding.ContentHashtagListBinding
import com.wooin95.otzzang.model.HashTag
import com.wooin95.otzzang.util.CredentialsManager
import com.wooin95.otzzang.util.NetworkHelper
import kotlinx.android.synthetic.main.activity_hash_tag_control.*
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class HashTagControlActivity : BaseActivity() {

    var dataArray = ArrayList<Any>()
    val dataAdapter by lazy { LastAdapter(dataArray, BR.content) }
    var call: Call<ArrayList<HashTag>>? = null
    val fromIntent by lazy { intent }
    override fun setDefault() {
        toolbarTitle = "해시태그 검색"
        initView()
    }

    private fun initView() {
        searchRecylerView.addItemDecoration(DividerItemDecoration(applicationContext, LinearLayout.VERTICAL))
        searchRecylerView.layoutManager = LinearLayoutManager(this@HashTagControlActivity)
        dataAdapter
                .map<String, ContentHashtagHeaderBinding>(R.layout.content_hashtag_header) {
                    onClick {
                        makeNewHashTag(searchQuery.text.toString().trim())
                    }
                }
                .map<HashTag, ContentHashtagListBinding>(R.layout.content_hashtag_list) {
                    onClick {
                        val position = it.adapterPosition
                        val item = dataArray[position] as HashTag
                        MaterialDialog.Builder(this@HashTagControlActivity)
                                .title("해시태그 추가")
                                .content("${item.tag} 해시태그를 추가하시겠습니까?")
                                .positiveText("추가")
                                .negativeText("취소")
                                .onPositive { dialog, which ->
                                    confirm(item.tag)
                                }
                                .show()
                    }
                }
                .into(searchRecylerView)
        searchQuery.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                getData(p0.toString().trim())
            }
        })
        getData("")
    }

    private fun getData(s: String) {
        call = NetworkHelper.networkInstance.findHashTagByQuery(CredentialsManager.instance.activeUser.second!!.token, s)
        call!!.enqueue(object : Callback<ArrayList<HashTag>> {
            override fun onFailure(call: Call<ArrayList<HashTag>>?, t: Throwable?) {
                Log.e("asdf", t!!.localizedMessage)
            }

            override fun onResponse(call: Call<ArrayList<HashTag>>?, response: Response<ArrayList<HashTag>>?) {
                val state = response!!.code()
                when (state) {
                    200 -> {
                        dataArray.clear()
                        if (s != "") dataArray.add("${s}을(를) 새로운 해시태그로 추가하기")
                        dataArray.addAll(response.body()!!)
                        dataAdapter.notifyItemRangeChanged(0, dataArray.size)
                        dataAdapter.notifyDataSetChanged()
                    }
                    else -> Log.e("asdf", response.message())
                }
            }
        })
    }

    private fun makeNewHashTag(s: String) {
        NetworkHelper.networkInstance.newHashTag(
                CredentialsManager.instance.activeUser.second!!.token, s).enqueue(object : Callback<ResponseBody> {
            override fun onFailure(call: Call<ResponseBody>?, t: Throwable?) {
                Log.e("asdf", t!!.localizedMessage)
            }

            override fun onResponse(call: Call<ResponseBody>?, response: Response<ResponseBody>?) {
                val state = response!!.code()
                when (state) {
                    200 -> {
                        getData(s)
                        MaterialDialog.Builder(this@HashTagControlActivity)
                                .title("해시태그 생성 완료")
                                .content("$s 해시태그가 새로 생성되었습니다!\n해당 해시태그를 추가하시겠습니까?")
                                .positiveText("추가")
                                .negativeText("취소")
                                .onPositive { dialog, which ->
                                    confirm(s)
                                }
                                .show()
                    }
                    409 -> Toast.makeText(applicationContext, "이미 존재하는 해시태그입니다!", Toast.LENGTH_SHORT).show()
                    else -> Log.e("asdf", response.message())
                }
            }
        })
    }

    private fun confirm(s: String) {
        fromIntent.putExtra("result", s)
        setResult(Activity.RESULT_OK, fromIntent)
        finish()
    }

    override val viewId: Int = R.layout.activity_hash_tag_control
    override val toolbarId: Int = R.id.toolbar
}
