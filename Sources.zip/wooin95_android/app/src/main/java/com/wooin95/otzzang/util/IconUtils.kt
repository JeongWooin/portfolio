package com.wooin95.otzzang.util

import android.util.Log
import com.wooin95.otzzang.R

object IconUtils {
    public fun getIcon(weatherStr: String, hour: Int): Int {
        val query = weatherStr.replace(" ", "").replace("/", "")
        if (query.contains("맑음")) {
            return if (isDayTime(hour)) R.drawable.normal else R.drawable.normal_night
        } else if (query.contains("구름조금")) {
            return if (isDayTime(hour)) R.drawable.cloudy else R.drawable.cloudy_night
        } else if (query.contains("구름많음")) {
            return if (isDayTime(hour)) R.drawable.cloudy_lot else R.drawable.cloudy_lot_night
        } else if (query.contains("흐림")) {
            return if (isDayTime(hour)) R.drawable.cloudy_lot else R.drawable.cloudy_lot_night
        } else if (query.contains("비") || query.contains("눈")) {
            return if (query.contains("비눈") || query.contains("눈비")) {
                if (isDayTime(hour)) R.drawable.snow_rain else R.drawable.snow_rain_night
            } else if (query.contains("비")) {
                if (isDayTime(hour)) R.drawable.rain else R.drawable.rain_night
            } else if (isDayTime(hour)) R.drawable.snow else R.drawable.snow_night

        }
        return R.drawable.normal
    }

    private fun isDayTime(hour: Int): Boolean {
        return hour in 6..19
    }
}