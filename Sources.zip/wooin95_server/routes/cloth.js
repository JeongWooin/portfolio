module.exports = cloth;

let random_string = require('randomstring');
let {User} = require('../DB/schema');
let {Cloth} = require('../DB/schema');
let {HashTag} = require('../DB/schema');
let upload = require('../func/multer').upload;
let async = require('async');
let ObjectId = require('mongodb').ObjectID;
const mongoose = require("mongoose");

async function cloth(app) {
    app.post("/cloth/list", (req, res) => {
        let token = req.body.token;
        let weather = req.body.weather;
        let clothType = parseInt(req.body.clothType);
        let searchQuery = {
            'usertoken': token
        };

        if (clothType !== -1) searchQuery['clothType'] = clothType;
        if(typeof weather === "string"){
            let query = [];
            query.push(weather);
            if(parseInt(weather) !== -1) searchQuery['weather'] = {"$in" : query};
        }
        else if(typeof weather === "object") {
            searchQuery['weather'] = {"$in" : weather};
        }
        Cloth.find(searchQuery, function (err, docs) {
            if (err) throw err;
            res.send(200, docs)
        })
    });

    app.post('/cloth/info', (req, res) => {
        let _id = req.body._id;

        Cloth.findOne({_id: _id}, function (err, doc) {
            if (err) throw err;
            if (doc != null) {
                res.send(200, doc)
            } else res.send(400, 'no data found')
        })
    });

    app.post('/cloth/new', (req, res) => {
        let token = req.body.token;
        let title = req.body.title;
        let weather = req.body.weather;
        let clothType = req.body.clothType;
        let hashTag = req.body.hashTag;
        let _id = random_string.generate();
        let hashs = [];

        if (typeof hashTag === 'string') hashs.push(hashTag);
        else if(hashTag === undefined) hashs = [];
        else hashs = hashTag;

        console.log(typeof hashs);
        let saveCloth = new Cloth({
            _id: _id,
            clothToken: random_string.generate(),
            usertoken: token,
            name: title,
            weather: weather,
            clothType: clothType,
            hashTag: hashs,
            imageName: ""
        });
        for (i = 0; i < hashs.length; i++) {
            console.log(hashs[i]);
            HashTag.findOneAndUpdate(
                {tag: hashs[i], userToken : token}, {$push: {clothTokens: _id}}, {returnNewDocument: true, new: true},
                (err, doc) => {
                    if (err) throw err;
                    console.log(doc);

                }
            )
        }
        saveCloth.save((err, model) => {
            if (err) console.log(err);
            console.log('saved cloth' + saveCloth.toString());
            res.send(200, saveCloth)
        });
    });

    app.post('/cloth/edit', (req, res) => {
        let id = req.body._id;
        let clothToken = req.body.clothToken;
        let usertoken = req.body.token;
        let title = req.body.title;
        let weather = req.body.weather;
        let clothType = req.body.clothType;
        let originHashTag = req.body.originHashTag;
        let hashTag = req.body.hashTag;
        let hashs = [];
        let originHashs = [];

        if (typeof hashTag === 'string') hashs.push(hashTag);
        else if(hashTag === undefined) hashs = [];
        else hashs = hashTag;

        if (typeof originHashTag === 'string') originHashs.push(originHashTag);
        else if(originHashTag === undefined) originHashs = [];
        else originHashs = originHashTag;

        for (i = 0; i < originHashs.length; i++) {
            HashTag.findOneAndUpdate(
                {tag: originHashs[i], userToken : usertoken}, {$pull: {clothTokens: id}}, {returnNewDocument: true, new: true},
                (err, doc) => {

                    if (err) throw err;
                    console.log(doc);
                }
            )
        }

        for (i = 0; i < hashs.length; i++) {
            HashTag.findOneAndUpdate(
                {tag: hashs[i], userToken : usertoken}, {$addToSet: {clothTokens: id}}, {returnNewDocument: true, new: true},
                (err, doc) => {
                    if (err) throw err;
                    console.log(doc);
                }
            )
        }

        Cloth.findOneAndUpdate(
            {
                clothToken: clothToken, usertoken: usertoken
            }, {
                name: title,
                weather: weather,
                clothType: clothType,
                hashTag: hashTag
            }, {
                returnNewDocument: true,
                new: true
            }, (err, doc) => {
                if (err) throw err;
                res.send(200, doc)
            }
        );
    });

    app.post('/cloth/edit/file', upload.single('file'), (req, res) => {
        let clothToken = req.body.clothToken;
        let usertoken = req.body.token;
        let filename = req.file.filename;

        Cloth.findOneAndUpdate(
            {
                clothToken: clothToken, usertoken: usertoken
            }, {
                imageName: filename
            }, {
                returnNewDocument: true,
                new: true
            }, (err, doc) => {
                if (err) throw err;
                res.send(200, doc)
            }
        );
    });


    app.post('/cloth/remove', (req, res) => {
            let id = req.body._id;
            let clothToken = req.body.clothToken;
            let userToken = req.body.userToken;

            if (clothToken === undefined || userToken === undefined) res.sendStatus(400);
            else Cloth.remove({clothToken: clothToken, usertoken: userToken}, (err, numAffected) => {
                if (err) throw err;
                res.sendStatus(200)
            })
        }
    );


    app.post('/cloth/removeAll', (req, res) => {
        let userToken = req.body.userToken;

        if (userToken === undefined) res.sendStatus(400);
        else Cloth.remove({usertoken: userToken}, (err, numAffected) => {
            if (err) throw err;
            else res.send(200, numAffected)
        })
    });

    app.post('/cloth/hashtag/new', (req, res) => {
        let title = req.body.title;
        let userToken = req.body.userToken;

        HashTag.findOne({tag: title, userToken : userToken}, ((err, doc) => {
            if (doc == null) {
                let newTag = new HashTag({
                    tag: title,
                    userToken : userToken
                });

                newTag.save((err, model) => {
                    if (err) throw err;
                    res.send(200, model)
                })
            } else res.sendStatus(409)
        }))
    });


    app.post('/cloth/hashtag/findExceptZero', (req, res) => {
        let query = req.body.query;
        let userToken = req.body.userToken;

        if (query === undefined) res.sendStatus(400);
        else HashTag.find({
            userToken : userToken,
            tag: {$regex: query},
            clothTokens: {$exists: true}, $where: 'this.clothTokens.length>0'
        }).populate('clothTokens').exec((err, docs) => {
            console.log(docs);
            if (err) console.error(err);
            res.send(200, docs)
        })
    });

    app.post('/cloth/hashtag/find', (req, res) => {
        let query = req.body.query;
        let userToken = req.body.userToken;

        if (query === undefined) res.sendStatus(400);
        else HashTag.find({
            userToken : userToken,
            tag: {$regex: query}
        }).populate('clothTokens').exec((err, docs) => {
            console.log(docs);
            if (err) console.error(err);
            res.send(200, docs)
        })
    });

    app.post('/cloth/hashtag/info', (req, res) => {
        let query = req.body.query;
        let userToken = req.body.userToken;

        if (query === undefined) res.sendStatus(400);
        else HashTag.findOne({
            tag: query,
            userToken : userToken,
        }).populate('clothTokens').exec((err, doc) => {
            if (err) throw err;
            else res.send(200, doc.clothTokens)
        })
    })
}