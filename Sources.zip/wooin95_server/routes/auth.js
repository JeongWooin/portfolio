module.exports = auth;

let random_string = require('randomstring');
let {User} = require('../DB/schema');
let async = require('async');

async function auth(app) {
    app.post('/auth/login', (req, res) => {
        "use strict";
        let email = req.body.email;
        let password = req.body.password;

        User.findOne({
            email: email,
            password: password
        }, (err, model) => {
            if (err) throw err;
            if (model == null || model === undefined) {
                res.sendStatus(401);
            } else {
                res.send(200, model);
            }
        });
    });

    app.post('/auth/login/auto', (req, res) => {
        "use strict";
        let token = req.body.token;
        User.findOne({
            token: token,
        }, (err, model) => {
            if (err) throw err;
            if (model.length == 0) {
                res.sendStatus(401);
            } else {
                res.send(200, model);
            }
        })
    });

    app.post('/auth/user/edit', (req, res) => {
        "use strict";
        let token = req.body.token;
        let name = req.body.name;
        let birthYear = req.body.birthYear;
        let sexType = req.body.sex;
        let weight = req.body.weight;
        let height = req.body.height;

        User.findOneAndUpdate({
            token: token,
        }, {
            name: name,
            birthYear: birthYear,
            sex: sexType,
            weight : weight,
            height : height
        }, {
            returnNewDocument: true,
            new: true
        }, (err, model) => {
            if (err) throw err;
            if (model.length == 0) {
                res.sendStatus(401);
            } else {
                res.send(200, model);
            }
        })
    });

    app.post('/auth/user/edit/password', (req, res) => {
        "use strict";
        let token = req.body.token;
        let password = req.body.password;
        let newPassword = req.body.newPassword;

        User.findOneAndUpdate({
            token: token,
            password: password
        }, {
            password: newPassword
        }, {
            returnNewDocument: true,
            new: true
        }, (err, model) => {
            if (err) throw err;
            if (model.length == 0) {
                res.sendStatus(401);
            } else {
                res.send(200, model);
            }
        })
    });

    app.post('/auth/register', (req, res) => {
        let email = req.body.email;
        let password = req.body.password;
        let nickname = req.body.nickname;
        let name = req.body.name;
        let birthYear = req.body.birthYear;
        let sex = req.body.sex;
        let weight = req.body.weight;
        let height = req.body.height;
        let token = random_string.generate();

        async.waterfall([
            function (cb) {
                User.find({email: email}, (err, model) => {
                    if (err) console.log(err);
                    if (model.length == 0) {
                        cb(null);
                        console.log('find, no user')
                    }
                    else {
                        cb(true, "User Already Exist");
                        console.log('find, user exists')
                    }
                });
            },
            function (cb) {
                console.log('saving user')
                let saveUser = new User({
                    token: token,
                    email: email,
                    password: password,
                    nickname: nickname,
                    name: name,
                    birthYear: birthYear,
                    sex: sex,
                    weight : weight,
                    height : height
                });

                saveUser.save((err, model) => {
                    if (err) console.log(err);
                    cb(null);
                    console.log('saved user' + saveUser.toString())
                });
            }
        ], function (cb, text) {
            if (cb == true) {
                res.sendStatus(409);
            }
            else if (cb == null) {
                res.sendStatus(200);
            }
        })
    });

    app.post('/auth/user/remove', (req, res) => {
        "use strict";
        let token = req.body.token;

        User.remove({
            token: token,
        }, (err, result) => {
            if (err) throw err;
            res.send(200, result);
        })
    });
}