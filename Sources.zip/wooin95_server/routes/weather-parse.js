module.exports = weather;

let async = require('async');
let iconv = require('iconv-lite');
let request = require('request');
let xml2json = require('xml2json');
let cheerio = require('cheerio');

function weather(app) {
    app.get('/weather/', function (req, res) {
        let lat = req.query.latitude;
        let lon = req.query.longitude;
        fetchWeather(lat, lon, res)
    })

}

function fetchWeather(latitude, longitude, httpResponse) {
    let options = {
        method: 'GET',
        url: 'https://dapi.kakao.com/v2/local/geo/coord2regioncode.json?x=' + longitude + '&y=' + latitude,
        headers: {
            'Authorization': "KakaoAK 79a33161bed251f72fb2a3e62504566e"
        }
    };
    request(options, function (error, response, body) {
        if (error) throw error;

        let data = JSON.parse(body).documents;
        let localCode = data[data.length - 1].code;
        let address = data[data.length - 1].address_name;

        console.log(localCode);
        let parseQueue = [getDustPm10(latitude, longitude), getUVvalue(latitude, longitude), getCurrentWeather(localCode), getCurrentHighLow(latitude, longitude), getTodayWeather(localCode), getWeekWeather(address)];

        console.log(data);
        async.parallel(parseQueue, function (err, results) {
            if (err) {
                httpResponse.sendStatus(500);
            }
            console.log(results);
            httpResponse.send(200, {
                'address': address,
                'pm10': results[0],
                'uvValue': results[1],
                'current': results[2].current,
                'todayTemps' : results[2].todayHighLow,
                'currentTempMax' : results[3].tempMax,
                'currentTempMin' : results[3].tempMin,
                'pubdate': results[4].pubDate,
                'today': results[4].data,
                'week': results[5]
            });

        })
    })
}

function getCurrentWeather(localCode) {
    return function (callback) {
        let url = 'http://www.weather.go.kr/weather/process/main-dfs-2017.jsp?myPointCode=' + localCode;
        let options = {
            method: 'GET',
            url: url,
            encoding: null
        };
        request(options, function (err, response, body1) {
            if (err) throw err;
            let body = iconv.decode(Buffer.from(body1), 'EUC-KR');
            let $ = cheerio.load(body);
            let sidos = $('div.weather_dfs > div:nth-child(2) > div > div > ul > li').map(function (i, item) {
                return $(this).text()
            }).get();
            let todayHighLow = $('tr.tommorow>td>dl>dd>span').map(function (i, item) {
                return $(this).text()
            }).get();
            callback(null, {
                'current' : sidos,
                'todayHighLow' : todayHighLow
            })
        })
    }
}

function getCurrentHighLow(latitude, longitude) {
    return function (callback) {
        let url = 'https://api.openweathermap.org/data/2.5/weather?lat=' + latitude + '&lon=' + longitude + '&appid=37e37865793eeeea71704a42f6db53dd';
        let options = {
            method: 'GET',
            url: url,
            encoding: null
        };
        request(options, function (err, response, body1) {
            if (err) throw err;
            let body = JSON.parse(body1);
            let tempMax = body.main.temp_max;
            let tempMin = body.main.temp_min;
            callback(null, {tempMax : tempMax, tempMin : tempMin})
        })
    }
}


function getTodayWeather(localCode) {
    return function (callback) {
        let options = {
            method: 'GET',
            url: 'http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=' + localCode
        };
        request(options, function (error, response, body) {
            if (error) console.log(error);
            let result = JSON.parse(xml2json.toJson(body));
            callback(null, {
                pubDate: result.rss.channel.pubDate,
                data: result.rss.channel.item.description.body.data
            })
        })
    }
}


function getWeekWeather(address) {
    return function (callback) {
        let weekWeatherCode = getWeekWeatherCode(address);
        console.log(weekWeatherCode + " " + address);
        let options = {
            method: 'GET',
            url: 'http://www.kma.go.kr/weather/forecast/mid-term-rss3.jsp?stnId=' + weekWeatherCode[0]
        };
        request(options, function (error, response, body) {
            if (error) console.log(error);
            let result = JSON.parse(xml2json.toJson(body));

            callback(null, result.rss.channel.item.description.body.location[weekWeatherCode[1]].data)
        })
    }
}

function getDustPm10(latitude, longitude) {
    return function (callback) {
        let options = {
            method: 'GET',
            url: 'https://api.waqi.info/feed/geo:' + latitude + ';' + longitude + '/?token=bbb18df92080233370f8acd7f72e8d3032bc2c4b'
        };
        request(options, function (err, response, body) {
            if (err) callback(err, null);
            let pm10 = {};
            try {
                pm10 = JSON.parse(body).data.iaqi.pm10.v;
            } catch (e) {
                pm10 = -1
            }
            callback(null, pm10)
        })
    }
}

function getUVvalue(latitude, longitude) {
    return function (callback) {
        let options = {
            method: 'GET',
            url: 'https://api.openweathermap.org/data/2.5/uvi?lat=' + latitude + '&lon=' + longitude + '&appid=37e37865793eeeea71704a42f6db53dd'
        };
        request(options, function (err, response, body) {
            if (err) console.log(err);
            let value = JSON.parse(body).value;

            callback(null, value)
        })
    }
}

function getWeekWeatherCode(address) {
    if (address.indexOf('서울') > -1) return [109, 0];
    else if (address.indexOf('인천') > -1) return [109, 1];
    else if (address.indexOf('경기도') > -1) return [109, 2];
    else if (address.indexOf('강원도') > -1) return [105, 0];
    else if (address.indexOf('충청북도') > -1) return [131, 0];
    else if (address.indexOf('충청남도') > -1) return [133, 0];
    else if (address.indexOf('전라북도') > -1) return [146, 0];
    else if (address.indexOf('전라남도') > -1) return [156, 0];
    else if (address.indexOf('경상북도') > -1) return [143, 0];
    else if (address.indexOf('경상남도') > -1) return [159, 0];
    else if (address.indexOf('제주') > -1) return [184, 0];
    else return [109, 0];
}

