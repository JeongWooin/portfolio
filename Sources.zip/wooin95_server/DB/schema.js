/**
 * Created by buddman1208 on 2018. 7. 20..
 */

let mongoose = require('mongoose');
let Logger = require('../func/color').Logger;

mongoose.connect('mongodb://localhost:27017/wooin95');
let db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function callback() {
    Logger.data("Mongo DB ON");
});

let user = new mongoose.Schema({
    token: {type: String},
    email: {type: String},
    password: {type: String},
    nickname: {type: String},
    name: {type: String},
    birthYear: {type: String},
    sex: {type: String},
    weight : {type : Number},
    height : {type : Number}
});

let cloth = new mongoose.Schema({
    _id: {type: String},
    clothToken: {type: String},
    name: {type: String},
    weather: {type: Array},
    clothType: {type: Number},
    usertoken: {type: String},
    hashTag: {type: Array},
    imageName: {type: String}
});

let hashTag = new mongoose.Schema({
    userToken : {type : String},
    tag: {type: String},
    clothTokens: [{type: String, ref: 'clothModel'}]
});

let clothModel = mongoose.model('clothModel', cloth);
let userModel = mongoose.model('userModel', user);
let hashTagModel = mongoose.model('hashTagModel', hashTag);

exports.User = userModel;
exports.Cloth = clothModel;
exports.HashTag = hashTagModel;